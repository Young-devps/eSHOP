for (let i = 1; i < 4; i++) {
    $.ajax({
        type : "POST",
        url : "../Traitement/Source/promo.php",
        data : null,
        success : function(server_respond){
            $("#"+i).html(server_respond);
        },
    });
}
setInterval(function () {
    for (let i = 1; i < 4; i++) {
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/promo.php",
            data : null,
            success : function(server_respond){
                $("#"+i).html(server_respond);
            },
        });
    }
}, 5000);

$('.anul').click(function () {
   $('#profil-edit').slideUp('slow').hide();
    $('#account-delete').slideUp('slow').hide();
    $('#command').css({'display': 'none'});
    $('#account-discon').slideUp('slow').hide();
    $('#cmd').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
   $('#home').show('slow');
});

$('#op-edit').click(function () {
    $('#account-delete').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#command').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#profil-edit').show('slow');
});

$('#cmd').click(function () {
    $('#account-delete').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#profil-edit').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#command').show('slow');
});

$('#discon').click(function () {
    $('#account-delete').slideUp('slow').hide();
    $('#profil-edit').slideUp('slow').hide();
    $('#command').css({'display': 'none'});
    $('#home').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#account-discon').show('slow');
});


$('#sup-com').click(function () {
    $('#profil-edit').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#command').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#account-delete').show('slow');
});

$('#com').click(function () {
    $('#profil-edit').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#command').css({'display': 'none'});
    $('#account-delete').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#cmd').show('slow');
});

$('#cmd-pas').click(function () {
    $('#profil-edit').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#account-delete').css({'display': 'none'});
    $('#reg').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#command').show('slow');
});

$('#regle').click(function () {
    $('#profil-edit').slideUp('slow').hide();
    $('#account-discon').slideUp('slow').hide();
    $('#home').css({'display': 'none'});
    $('#command').css({'display': 'none'});
    $('#account-delete').css({'display': 'none'});
    $('#cmd').css({'display': 'none'});
    $('#reg').show('slow');
});

