$('.dropdown-toggle').addClass('border-0').addClass('bg-transparent');
$('.dropdown').click(function () {
    $('.dropdown-toggle').dropdown();
});

$('#b-search').click(function () {
    $('#field').hide('slow');
    $('#f-search').show('slow');
});

$('#res').click(function () {
    $('#f-search').hide('slow');
    $('#field').show('slow');
});