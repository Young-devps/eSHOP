$('#auth-link').click('slow', function () {
    $('#desc').hide();
    $('#serv').hide();
    $('#part').hide();
    $('#auth').show('slow');
    $('.anime').css({
        'transition-duration': '2s'
    }).animate({
        top : '-0px',
        opacity : '1'
    });
});

$('#desc-link').click('slow', function () {
    $('#auth').hide();
    $('#serv').hide();
    $('#part').hide();
    $('#desc').show('slow').addClass('fades');
});

$('#part-link').click('slow', function () {
    $('#auth').hide();
    $('#serv').hide();
    $('#desc').hide();
    $('#part').show('slow').addClass('fades');
});

$('#serv-link').click('slow', function () {
    $('#auth').hide();
    $('#part').hide();
    $('#desc').hide();
    $('#serv').show('slow').addClass('fades');
});
