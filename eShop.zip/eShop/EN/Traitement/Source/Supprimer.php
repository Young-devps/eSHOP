<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 3:35 PM
 */
session_start();
echo $_SESSION['ID'];
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "DELETE FROM Utilisateur WHERE eID = ?");
$req->execute(array($_SESSION['ID']));
header('location:deconnecter.php');
?>