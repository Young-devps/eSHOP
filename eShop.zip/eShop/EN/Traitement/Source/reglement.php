<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/11/2019
 * Time: 6:50 AM
 */

include_once '../../Donnees/PHP/Lister.php';

session_start();


$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "SELECT Ref_Comm FROM Reglement WHERE Ref_Comm = ?");
$req->execute(array($_GET['c']));
$num = $req->rowCount();

$code_client = gClientCode($_GET['c']);
$client = getClientInfo($code_client, "Nom");
$code_produit = gProduitRef($_GET['c']);
$produit = getProduitInfo($code_produit, "Libelle");
$pu = getProduitInfo($code_produit, "Montant");
$qte = Concerner($_GET['c'], "Quantite");
$date = Commande($_GET['c'], "Date_Comm");
$prix = intval(intval($pu)*intval($qte));

$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "INSERT INTO Reglement VALUES(?, ?, ?, ?)");
$req->execute(array($_GET['c'], $code_client, date('d-m-Y'), $prix));

if($num == 0){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT Quantite FROM Produit WHERE Ref_Prod = ?");
    $req->execute(array($code_produit));
    $res = $req->fetch();
    $aQte = $res[0];

    $nQ = intval($aQte - $qte);
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "UPDATE Produit SET Quantite = ? WHERE Ref_PRod = ?");
    $req->execute(array($nQ, $code_produit));
}

if($_GET['opt']=="mtn"){
    $img = "mtn.jpg";
}
else if($_GET['opt']=="orange"){
    $img = "orange.png";
}
else if($_GET['opt']=="nexttel"){
    $img = "nexttel.png";
}
else if($_GET['opt']=="eu"){
    $img = "eu.png";
}
else{
    $img = "favicone.png";   
}
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop Receipt: <?=$_GET['c'];?></title>
    <link rel="shortcut icon" type="image/png" href="../../Donnees/Fichier/favicone.png">
    <link rel="stylesheet" href="../../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../../Presentation/Style/Espace.css">
</head>
<body onload="window.print();">
    <header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
        <center>
            <img src="../../Donnees/Fichier/favicone.png" width="50" height="50">
            <span  style="font-size:25px">
                <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
            </span>
        </center>
        <div class="text-left">
            <a href="../../Presentation/Espace.php?ID=<?=$_SESSION['ID'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-home"></b> Accueil</a>
        </div>
    </header>

    <center>
        <div id="facture" class="img-thumbnail pb-2 mt-2" style="width: 700px">
            <div class="text-left">
                <img src="../../Donnees/Fichier/favicone.png" width="100" height="100"><br>
                <b class="text-center ml-4 logo">E</b>Shop
                <img src="../../Donnees/Fichier/<?=$img;?>" style="position: relative; top: -100px; left: 500px;" width="100" height="100"><br>
            </div>
            <div class="text-center">
                <h6>Receipt N<sup>o</sup> <b><?=$_GET['c']."-".$code_produit;?></b></h6>
            </div><br>
            <hr class="ml-5 mr-5">
            <img src="../../Donnees/Fichier/Data/<?=$code_produit?>.png" class="rounded-circle" width="100" height="100"><br>
            Product : <b><?=$produit;?></b><br>
            Price : <b><?=$pu;?></b><br>
            Quantity : <b><?=$qte;?></b><br>
            <hr class="ml-5 mr-5">
            Client : <b><?=$client;?></b><br>
            <hr class="ml-5 mr-5">
            <span style="position: relative; left: -150px;" class="text-left">Done on the <?=$date;?></span>
            <span style="position: relative; left: 150px;" class="text-right">Total Paid : <b class="text-primary"><?=$prix;?></b></span>
        </div>

        <button type="button" class="m-3 btn btn-special"><b class="fa fa-print"></b> Print</button>
    </center>

    <footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
        <center>
            <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , All right reserved</span>
        </center>
    </footer>
    <script src="../../Traitement/Script/jquery-3.3.1.min.js"></script>
    <script src="../../Traitement/Script/eShop.js"></script>
    <script src="../../Traitement/Script/eFont.js"></script>
    <script>
        $('.btn-special').click(function () {
            window.print();
        });
    </script>
</body>
</html>

