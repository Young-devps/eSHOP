<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 12:42 PM
 */
session_start();
if(isset($_SESSION['Type'])){
	$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
	$req = $db->prepare( "SELECT SUM(Montant) FROM Reglement");
	$req->execute(array());
	$res = $req->fetch();
	echo $res[0];	
}
else{
	$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
	$req = $db->prepare( "SELECT SUM(Montant) FROM Reglement WHERE Code_Cl = ?");
	$req->execute(array($_POST['id']));
	$res = $req->fetch();
	echo $res[0];	
}

?>