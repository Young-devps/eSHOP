<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/10/2019
 * Time: 3:21 AM
 */
function getCode($nom){
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "SELECT Code_Cl FROM Client WHERE Nom = ?");
$req->execute(array($nom));
$rs = $req->fetch();
return $rs['Code_Cl'];
}

include_once '../../Donnees/PHP/CodeGen.php';
$com = CodeCommande();
session_start();

$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "INSERT INTO Commande VALUES(?, ?, ?)");

if(isset($_REQUEST['client']) and isset($_SESSION['Type'])){
	$req->execute(array($com, date('d-m-Y'), getCode($_REQUEST['client'])));	
}
else if(!isset($_REQUEST['client']) or !isset($_SESSION['Type'])){
	$req->execute(array($com, date('d-m-Y'), $_SESSION['ID']));	
}

$req = $db->prepare( "INSERT INTO Concerner VALUES(?, ?, ?)");
$req->execute(array($com, $_GET['ID'], $_POST['qte']));
header("location: ../../Presentation/Espace?ID=".$_SESSION['ID']);

?>