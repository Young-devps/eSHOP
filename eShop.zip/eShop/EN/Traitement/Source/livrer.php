<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/12/2019
 * Time: 2:59 AM
 */
session_start();

include_once '../../Donnees/PHP/CodeGen.php';

$liv = CodeLivraison();

if(isset($_GET['com'])){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "INSERT INTO Livraison VALUES(?, ?)");
    $req->execute(array($liv, $_GET['com']));
    header("location:livraison.php?liv=".$liv."&c=".$_GET['com']);
}

?>