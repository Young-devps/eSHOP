<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
 session_start();
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Mon Compte</title>
    <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
    <link rel="stylesheet" href="../../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../../Presentation/Style/Espace.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../../Donnees/Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
    <?php include_once '../../Donnees/PHP/Lister.php'; if(isset($_GET['type']) and $_GET['type'] == "c"):?>
        <a href="../../Presentation/Structure.php?param=c" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;">
        <b class="text-danger fa fa-arrow-left"></b> Back</a>
    <?php endif; ?>
    <?php include_once '../../Donnees/PHP/Lister.php'; if(isset($_GET['type']) and $_GET['type'] == "p"):?>
        <a href="../../Presentation/Structure.php?param=p" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;">
        <b class="text-danger fa fa-arrow-left"></b> Back</a>
    <?php endif; ?>
    </div>
</header>

<?php include_once '../../Donnees/PHP/Lister.php'; if(isset($_GET['type']) and $_GET['type'] == "c"):?>
    <center>
        <form id="form" class="text-dark ml-3" method="post" action='update.php?code=<?=$_GET['client'];?>&type=c' style="min-height: 400px; max-height: 400px">
            <center>
                <b id="form-legend" class="text-dark fa fa-user" style="background-color: #fff; font-size: 75px; padding: 10px"></b><br>
                <h5><b class="logo">E</b>Shop Account</h5>
            </center>
            <center>
                <div id="group1">
                    <div class="group">
                        <input type="text" value="<?=getClientInfo($_GET['client'], 'Nom');?>" class="input" name="nom" id="nom" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Name</label>
                    </div>

                    <div class="group">
                        <input type="text" value="<?=getClientInfo($_GET['client'], 'Adresse');?>" name="addr" id="addr" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Adress or Phone Number</label>
                    </div>

                    <div class="group">
                        <input type="text" name="vil" id="vil" value="<?=getClientInfo($_GET['client'], 'Ville');?>" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Town</label>
                    </div>

                    <div style="color: #fff; padding: 5px;">
                        <button type="submit" id="suiv" class="btn btn-success">Update <b class="fa fa-arrow-right"></b></button><br><br>
                    </div>
                </div>
            </center>
        </form>
    </center>
<?php endif; ?>

<?php include_once '../../Donnees/PHP/Lister.php'; if(isset($_GET['type']) and $_GET['type'] == "p"):?>
    <center>
        <form id="form" class="text-dark ml-3" method="post" action='update.php?code=<?=$_GET['produit'];?>&type=p' style="min-height: 400px; max-height: 400px">
            <center>
                <b id="form-legend" class="text-dark fa fa-user" style="background-color: #fff; font-size: 75px; padding: 10px"></b><br>
                <h5><b class="logo">E</b>Shop Product</h5>
            </center>
            <center>
                <div id="group1">
                    <div class="group">
                        <input type="text" value="<?=getProduitInfo($_GET['produit'], 'Libelle');?>" class="input" name="nom" id="nom" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Label</label>
                    </div>

                    <div class="group">
                        <input type="text" value="<?=getProduitInfo($_GET['produit'], 'Montant');?>" name="addr" id="addr" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Price</label>
                    </div>

                    <div class="group">
                        <input type="text" name="vil" id="vil" value="<?=getProduitInfo($_GET['produit'], 'Quantite');?>" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Quantity;</label>
                    </div>

                    <div style="color: #fff; padding: 5px;">
                        <button type="submit" id="suiv" class="btn btn-success">Update <b class="fa fa-arrow-right"></b></button><br><br>
                    </div>
                </div>
            </center>
        </form>
    </center>
<?php endif; ?>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , All right reserved</span>
    </center>
</footer>
<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
</body>
</html>
