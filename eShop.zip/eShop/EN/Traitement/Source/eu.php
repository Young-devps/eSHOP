<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/11/2019
 * Time: 4:06 AM
 */
$eu = $_POST['eu'];
if(strlen($eu) == 9 and ($eu[0].$eu[1] == "66" or $eu[0].$eu[1] == "69" or $eu[0].$eu[1] == "65" or $eu[0].$eu[1] == "67" or $eu[0].$eu[1] == "68" or $eu[0].$eu[1] == "22" or $eu[0].$eu[1] == "23")){
    echo "<b class='text-success'>OK</b>";
}
else{
    echo "Invalid Number";
}
?>