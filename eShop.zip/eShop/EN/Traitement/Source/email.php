<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 3:03 AM
 */
$email = $_POST['mail'];
mail($email, "Newsletter Subscription", "WELCOME TO OUR NEWSLETTER<br>You will receive our offers and promotions by mail", "De: eShop Inc ".date('Y'));
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "INSERT INTO Newsletter(email) VALUES(?)");
$req->execute(array($email));
header('location:../../');
?>