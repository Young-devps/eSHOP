<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:34 PM
 */

include_once '../../Donnees/PHP/Ajout.php';
include_once '../../Donnees/PHP/CodeGen.php';

$code = CodeClient();
$nom = strtoupper($_POST['nom']);
$adr = $_POST['adress'];
$vil = $_POST['ville'];
$log = $_POST['login'];
$mdp = sha1($_POST['code']);
$data = array($code, $nom, $adr, $vil, "A", $log, $mdp);

if(Ajout("CLI", $data) == true){
    echo 0;
}
else{
    echo -1;
}

?>