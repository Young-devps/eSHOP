<?php
session_start();
if($_GET['type']=='c'){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "DELETE FROM Client WHERE Code_Cl = ?");
    $req->execute(array($_GET['client']));
    header("location:../../Presentation/Structure.php?param=c");
}
if($_GET['type']=='p'){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "DELETE FROM Produit WHERE Ref_Prod = ?");
    $req->execute(array($_GET['produit']));
    header("location:../../Presentation/Structure.php?param=p");
}
?>