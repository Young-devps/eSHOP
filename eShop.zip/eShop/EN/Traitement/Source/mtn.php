<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/11/2019
 * Time: 4:06 AM
 */
$mtn = $_POST['mtn'];
if(strlen($mtn) == 9 and ($mtn[0].$mtn[1] == "67" or $mtn[0].$mtn[1] == "65" or $mtn[0].$mtn[1] == "68")){
    echo "<b class='text-success'>OK</b>";
}
else{
    echo "Invalid number";
}
?>