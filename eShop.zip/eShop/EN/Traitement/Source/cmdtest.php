<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/10/2019
 * Time: 3:21 AM
 */

function testQte($id, $q){
    if(filter_var($q)){
        if($q > 0){
            $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
            $req = $db->prepare( "SELECT Quantite FROM Produit WHERE Ref_Prod = ?");
            $req->execute(array($id));
            $res = $req->fetch();
            $qte = $res['Quantite'];
            if(intval($q) <= intval($qte)){
                echo "0";
            }
            else{
                echo "-3";
            }
        }
        else{
            echo "-2";
        }
    }
    else{
        echo "-1";
    }
}

testQte($_POST['ID'], $_POST['QTE']);
?>