<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/10/2019
 * Time: 12:43 PM
 */
include_once '../../Donnees/PHP/CodeGen.php';
$com = CodeCommande();
session_start();
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "UPDATE Commande SET Date_Comm = ? WHERE Ref_Comm = ?");
$req->execute(array(date('d-m-Y'), $_GET['ID']));
$req = $db->prepare( "UPDATE Concerner SET Quantite = ? WHERE Ref_Comm = ?");
$req->execute(array($_POST['qte'], $_GET['ID']));
header("location: ../../Presentation/Espace?ID=".$_SESSION['ID']);
?>