<?php

if($_GET['type'] == "c"){
    $nom = $_POST['nom'];
    $adr = $_POST['addr'];
    $vil = $_POST['vil'];

    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
    $rq = $bdd->prepare("UPDATE Client SET Nom = ? , Adresse = ? , Ville = ? WHERE Code_Cl = ?");
    $rq->execute(array($nom, $adr, $vil, $_GET['code']));
    header('location:../../Presentation/Structure.php?param=c');
}
if($_GET['type'] == "p"){
    $nom = $_POST['nom'];
    $adr = $_POST['addr'];
    $vil = abs($_POST['vil']);
    try{
    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
    $rq = $bdd->prepare("UPDATE Produit SET Libelle = ? , Montant = ? , Quantite = ? WHERE Ref_Prod = ?");
    $rq->execute(array($nom, $adr, $vil, $_GET['code']));
    }
    catch(PDOException  $e){
    die($e);
    }
    header('location:../../Presentation/Structure.php?param=p');
}

?>