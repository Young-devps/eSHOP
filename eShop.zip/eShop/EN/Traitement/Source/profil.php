<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 1:13 PM
 */

$id = $_GET['token'];
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "UPDATE Client SET Nom = ?, Adresse = ?, Ville = ? WHERE Code_Cl = ?");
$req->execute(array($_POST['nom'],$_POST['addr'],$_POST['vil'],$id));
if(!empty($_POST['pass'])){
    $req = $db->prepare( "UPDATE Utilisateur SET Login = ?, Code = ? WHERE eID = ?");
    $req->execute(array($_POST['login'],sha1($_POST['pass']),$id));
}
else{
    $req = $db->prepare( "UPDATE Utilisateur SET Login = ? WHERE eID = ?");
    $req->execute(array($_POST['login'],$id));
}
header('location:../../Presentation/Espace.php');

?>