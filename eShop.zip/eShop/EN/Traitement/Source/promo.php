<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/7/2019
 * Time: 5:10 PM
 */

include_once '../../Donnees/PHP/Nombre.php';

function gPromotion($id, $champ){
    $db = mysqli_connect('localhost', 'root', '', 'Gestion') or die("Erreur 502");
    $req = mysqli_query($db, "SELECT * FROM Promotion");
    $tab = array();
    $i = 0;
    if($req){
        while($data = mysqli_fetch_assoc($req)){
            $tab[$i]['ID'] =  $data['Ref_Prod'];
            $tab[$i]['nPrix'] = $data['nPrix'];
            $i = $i + 1;
        }
        return $tab[$id][$champ];
    }
}

function gNom($id){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT Libelle FROM Produit WHERE Ref_Prod = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res['Libelle'];
}

function aPrix($id){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT Montant FROM Produit WHERE Ref_Prod = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res['Montant'];
}

$l = CompteLigneTable('Promotion') - 1;
$r = mt_rand(0, $l);
echo "<img src='../Donnees/Fichier/Data/".gPromotion($r, 'ID').".png' class='prod rounded-circle' width='150' height='150'><br>".
    "<span class='text-muted small'>".gNom(gPromotion($r, 'ID'))."</span><br>".
    "<div><strike class='text-danger'>".gPromotion($r, 'nPrix')."</strike> <b class='fa fa-arrow-right'></b> ".
    "<b class='badge badge-success'>".aPrix(gPromotion($r, 'ID'))."</b></div>";
?>