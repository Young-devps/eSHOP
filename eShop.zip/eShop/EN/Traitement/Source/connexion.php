<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 5:12 AM
 */

include_once '../../Donnees/PHP/Test.php';

if(isAuthentify($_POST['login'], $_POST['code']) == true){
    echo 0;
}
else{
    echo -1;
}

?>