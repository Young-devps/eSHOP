<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 2:32 PM
 */
session_start();
$_SESSION['ID'] = "";
unset($_SESSION['ID']);
session_destroy();
header("location:../../");
?>