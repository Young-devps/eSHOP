<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 4:06 PM
 */
session_start();
if(isset($_SESSION['Type'])){
	$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
	$req = $db->prepare( "SELECT COUNT(*) FROM Reglement");
	$req->execute();
	$res = $req->fetch();
	echo $res[0];
}
else{
	$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
	$req = $db->prepare( "SELECT COUNT(*) FROM Reglement WHERE Code_Cl = ?");
	$req->execute(array($_POST['id']));
	$res = $req->fetch();
	echo $res[0];
}

?>