<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/10/2019
 * Time: 12:44 PM
 */
session_start();
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "DELETE FROM Commande WHERE Ref_Comm = ?");
$req->execute(array($_GET['ID']));
$req = $db->prepare( "DELETE FROM Concerner WHERE Ref_Comm = ?");
$req->execute(array($_GET['ID']));
header("location: ../../Presentation/Espace?ID=".$_SESSION['ID']);

?>