<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 5:43 AM
 */
session_start();
$_SESSION['Type'] = "";
unset($_SESSION['Type']);
$bdd = new PDO("mysql:host=localhost; dbname=Gestion", "root", "");

if(isset($_POST['login']) and isset($_POST['pass'])){
    $login = $_POST['login'];
    $pass = sha1($_POST['pass']);
    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", "root", "");

    $rq = $bdd->prepare("SELECT eID, Type FROM Utilisateur WHERE Login = ? AND Code = ?");
    $rq->execute(array($login, $pass));
    $res = $rq->fetch();
    $_SESSION['ID'] = $res['eID'];
    if($res['Type'] == "A"){
        $_SESSION['Type'] = "A";
    }

}
if(isset($_GET['ID'])){
    $rq = $bdd->prepare("SELECT eID, Type FROM Utilisateur WHERE eID = ?");
    $rq->execute(array($_GET['ID']));
    if($rq->rowCount()!=0){
        $_SESSION['ID'] = $_GET['ID'];
        $res = $rq->fetch();
        if($res['Type'] == "A"){
            $_SESSION['Type'] = "A";
        }
    }
    else{
        unset($_SESSION['ID']);
    }
}

$rq = $bdd->prepare("SELECT Nom, Ville, Adresse FROM Client WHERE Code_Cl = ?");
$rq->execute(array($_SESSION['ID']));
$res = $rq->fetch();

$_SESSION['Nom'] = $res['Nom'];
$_SESSION['Adresse'] = $res['Adresse'];
$_SESSION['Ville'] = $res['Ville'];

if(isset($_SESSION['ID']) and !empty($_SESSION['ID'])){
?>
<!DOCTYPE html>
    <html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
        <title>eShop: La Boutique de Reference</title>
        <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
        <link rel="stylesheet" href="../Presentation/Style/eFont.css">
        <link rel="stylesheet" href="../Presentation/Style/eShop.css">
        <link rel="stylesheet" href="../Presentation/Style/Style.css">
        <link rel="stylesheet" href="../Presentation/Style/Espace.css">
    </head>
    <body>
        <header id="head">
            <center>
                <div class="d-inline-flex">
                    <img src="../Donnees/Fichier/1f4b5.png" class="anim h-img mr-5 rounded-circle"/>
                    <h2><b class="logo">E</b>-Shop</h2>
                    <img src="../Donnees/Fichier/1f4b7.png" class="anim h-img ml-5 rounded-circle"/>
                </div>
                <hr style="background: #fff; width: 500px">
                <h4 style="color: #757575;">La Boutique de Reference</h4>
            </center>
            <hr style="background-color: #505050;">
            <div class="text-sm-left small d-inline-flex">
                <div class="dropdown">
                    <button class="btn-sm text-white btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Gestion de Compte <b class="fa fa-user text-primary"></b>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
                            <a class="dropdown-item" href="Inscript.php"><b class="fa fa-user-plus text-white"></b> Creer un Compte</a>
                        <?php endif; ?>
                        <a class="dropdown-item" id="op-edit" href="#"><b class="fa fa-user-edit text-white"></b> Editer Mon Compte</a>
                        <a class="dropdown-item" id="sup-com" href="#"><b class="fa fa-user-times text-warning"></b> Supprimer Mon Compte</a>
                        <a class="dropdown-item" id="discon" href="#"><b class="fa fa-power-off text-danger"></b> D&eacute;connexion</a>
                    </div>
                </div> <b style="font-size: 20px">| </b>
                <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
                    <div class="dropdown">
                        <button class="btn-sm text-white btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Structure <b class="fa fa-gear text-white"></b>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="Structure.php?param=c"><b class="fa fa-users text-warning"></b> Client</a>
                            <a class="dropdown-item" href="Structure.php?param=p"><b class="fa fa-shopping-bag text-danger"></b> Produit</a>
                        </div>
                    </div> <b style="font-size: 20px">| </b>
                <?php endif; ?>
                <div class="dropdown">
                    <button class="btn-sm text-white btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Traitement <b class="fa fa-gears text-white"></b>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <a class="dropdown-item" href="#" id="cmd-pas"><b class="fa fa-cc text-warning"></b> Passer une Commande</a>
                        <a class="dropdown-item" href="#" id="com"><b class="fa fa-shopping-bag text-warning"></b> Mes Commandes</a>
                        <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
                            <a class="dropdown-item" href="Livraison.php"><b class="fa fa-truck-loading text-white"></b> Livrer un Produit</a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="#" id="regle"><b class="fa fa-money-bill text-danger"></b> Regler une Facture</a>
                    </div>
                </div> <b style="font-size: 20px">| </b>
                <div class="dropdown">
                    <button class="btn-sm text-white btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Impr&eacute;ssion <b class="fa fa-print text-info"></b>
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
                            <a class="dropdown-item" href="Donnees.php?liste=cl"><b class="fa fa-users text-white"></b> Liste des Clients</a>
                        <?php endif; ?>
                        <a class="dropdown-item" href="Donnees.php?liste=li"><b class="fa fa-truck text-danger"></b> Liste des Livraisons</a>
                        <a class="dropdown-item" href="Donnees.php?liste=pr"><b class="fa fa-briefcase text-secondary"></b> Liste des Produits</a>
                        <a class="dropdown-item" href="Donnees.php?liste=fa"><b class="fa fa-money-bill-alt text-warning"></b> Liste des Factures</a>
                        <a class="dropdown-item" href="Donnees.php?liste=cm"><b class="fa fa-cc text-success"></b> Bon Commande</a>
                    </div>
                </div>
            </div>
        </header>

        <main style="display: block" id="home">
            <div class="row d-inline-flex">
                <div class="col-sm-1 text-white" id="b-profil" style="padding: 25px; background-color: #242424; margin: 50px;">
                    <center>
                        <div><?php  include_once '../Donnees/PHP/Photo.php'; maPhoto($_SESSION['ID']); ?></div>
                        Bienvenue M. <b class="text-warning"><?=$_SESSION['Nom'];?></b><br>
                        <span class="small">De <i><?=$_SESSION['Ville'];?></i>(<i class="fa fa-map-marker text-warning"></i>)</span>
                        <hr class="mr-5 ml-5 bg-white">
                        <span title="Total de D&eacute;pense" class="small">
                            <b class="fa fa-dollar-sign text-warning"></b>
                            Depenses : <span id="depens" class="badge badge-pill badge-danger">0</span>
                        </span><br>
                        <span title="Nombre d'achats" class="small">
                            <b class="fa fa-exchange-alt text-warning ml-3"></b>
                            Transactions : <span id="trans" class="badge badge-pill badge-danger">0</span>
                        </span>
                    </center>
                </div>
                <div class="col-sm-7" style="padding:5px; margin: 0;">
                    <center>
                        <div class="d-inline-flex mt-lg-5" style="padding:0">
                            <span id="1" class="ml-lg-5" style="margin-right: 50px;"></span>
                            <span id="2" class="ml-lg-5 mr-lg-5" style="margin: 0 30px 0 30px;"></span>
                            <span id="3" class="ml-lg-5"style="margin-left: 50px;"></span>
                        </div>
                    </center>
                </div>
            </div>
        </main>
        
        <center>

            <div style="display: none; overflow: auto" id="reg">
                <h4>Reglement de Facture</h4>
                <hr class="mr-5 ml-5">
                <table>
                    <tr class="t-head"><td>Ref&eacute;rence</td><td>Client</td><td>Produit</td><td>Quantit&eacute</td><td>Date de Commande</td><td>Action</td></tr>
                    <?php
                    include_once '../Donnees/PHP/Lister.php';
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');

                    if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"){
                        $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Commande.Ref_Comm = Concerner.Ref_Comm");
                        $req->execute(array());
                    }
                    else{
                        $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Code_Cl = ? AND Commande.Ref_Comm = Concerner.Ref_Comm");
                        $req->execute(array($_SESSION['ID']));
                    }
                    while($res = $req->fetch()){
                        $ret = $db->prepare( "SELECT Quantite FROM Produit WHERE Ref_Prod = ?");
                        $ret->execute(array($res[4]));
                        $data = $ret->fetch();
                        $disp = $data[0];
                        echo "<tr>".
                            "<td>".$res[0]."</td><td>".getClientInfo($res[2], "Nom")."</td>".
                            "<td>".getProduitInfo($res[4],"Libelle")."</td>";
                            if($disp < $res[5]){
                                echo "<td>".$disp." <b class='text-danger'>Quantit&eacute; Modifi&eacute;</b></td>";
                            }
                            else{
                                echo "<td>".$res[5]."</td>";
                            }
                            echo "<td>".$res[1]."</td>".
                            "<td>";
                            if(isRegle($res[0]) == true){
                                echo "<b class='text-success'>Regl&eacute;e</b>";
                            }
                            else{
                                echo "<a href='Reglement.php?com=".$res[0]."&mnt=".intval(intval(getProduitInfo($res[4],"Montant"))*intval($res[5]))."'><button class='btn btn-primary'>Regler</button></a>";
                            }
                            echo "</td>".
                            "</tr>";
                    }
                    ?>
                </table>
            </div>

            <div style="margin-top: 10px">
                <section id="account-delete" style="display: none; max-width: 500px; padding: 25px; background-color: #e3e3e3;">
                    <h3>Voulez-vous vraiment effectuer cette action?</h3>
                    <hr class="mt-3 mb-3">
                    <a href="../Traitement/Source/Supprimer.php"><button type="button" class="btn btn-danger">Oui</button></a>
                    <button type="button" class="anul btn btn-warning">Non</button>
                </section>

                <section id="account-discon" class="mt-3" style="display: none; max-width: 500px; padding: 25px; background-color: #e3e3e3;">
                    <h3>Voulez-vous vraiment vous deconnectez?</h3>
                    <hr class="mt-3 mb-3">
                    <a href="../Traitement/Source/deconnecter.php"><button type="button" class="btn btn-danger">Deconnecter</button></a>
                    <button type="button" class="btn btn-warning anul">Annuler</button>
                </section>

                <section id="profil-edit" style="display: none">
                    <form id="form" class="text-dark ml-3" method="post" action="../Traitement/Source/profil.php?token=<?=$_SESSION['ID'];?>" style="min-height: 600px; max-height: 600px">
                        <center>
                            <b id="form-legend" class="text-dark fa fa-user small" style="background-color: #fff;font-size: 14px; padding: 7px"></b><br>
                            <h5>Compte <b class="logo">E</b>Shop</h5>
                        </center>
                        <center>
                            <div>
                                <div class="group">
                                    <input type="text" class="input" value="<?php include_once '../Donnees/PHP/Profil.php'; echo getProfil($_SESSION['ID'], 0, "Nom")?>" name="nom" id="nom" required>
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label class="label">Nom</label>
                                </div>

                                <div class="group">
                                    <input value="<?php include_once '../Donnees/PHP/Profil.php'; echo getProfil($_SESSION['ID'], 0, "Adresse")?>" type="text" name="addr" id="addr" class="input" required>
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label class="label">Adresse ou Telephone</label>
                                </div>

                                <div class="group">
                                    <input value="<?php include_once '../Donnees/PHP/Profil.php'; echo getProfil($_SESSION['ID'], 0, "Ville")?>" type="text" name="vil" id="vil" class="input" required>
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label class="label">Ville de Residence</label>
                                </div>
                            </div>
                            <div>
                                <div class="group">
                                    <input value="<?php include_once '../Donnees/PHP/Profil.php'; echo getProfil($_SESSION['ID'], 1, "Login")?>" type="text" class="input" name="login" id="login" required>
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label class="label">Login</label>
                                </div>
                                <div class="group">
                                    <input type="password" name="pass" id="pass" class="input">
                                    <span class="highlight"></span>
                                    <span class="bar"></span>
                                    <label class="label">Mot de Passe</label>
                                </div>
                                <span class="text-muted small">Laisser vide pour ne pas changer</span>
                                <br>
                            </div>
                            <div style="color: #fff; padding: 5px;"><br>
                                <button type="button" class="anul btn btn-danger">Annuler <b class="fa fa-window-close"></b></button>
                                <button type="submit"  class="btn btn-success">Mettre &agrave; Jour <b class="fa fa-arrow-right"></b></button><br><br>
                            </div>
                        </center>
                    </form>
                </section>
            </div>

            <div style="display: none;overflow: auto" id="cmd">
                <h4>Mes Commandes</h4>
                <hr class="mr-5 ml-5">
                <table>
                    <tr class="t-head"><td>Ref&eacute;rence</td><td>Produit</td><td>Quantit&eacute</td><td>Date de Commande</td><td>Action</td></tr>
                    <?php
                    include_once '../Donnees/PHP/Lister.php';
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');

                    if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A") {
                        $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Commande.Ref_Comm = Concerner.Ref_Comm");
                        $req->execute(array());
                        while($res = $req->fetch()){
                            echo "<tr>".
                                "<td>".$res[0]."-(".getClientInfo($res[2],"Nom").")</td>".
                                "<td>".getProduitInfo($res[4],"Libelle")."</td>".
                                "<td>".$res[5]."</td>".
                                "<td>".$res[1]."</td>";
                            if(isRegle($res[0]) == false){
                                echo "<td>".
                                    "<a href='mCommande.php?token=".$_SESSION['ID']."&ref=".$res[4]."&old=".$res[5]."&com=".$res[0]."'><b class='fa fa-edit text-success mr-3'></b></a>".
                                    "<a href='../Traitement/Source/dcommand.php?ID=".$res[0]."'><b class='fa fa-trash-o text-danger'></b></a>".
                                    "</td>";
                            }
                            else{
                                echo "<td class='text-success'>Commande Regl&eacute;e</td>";
                            }
                            echo "</tr>";
                        }
                    }
                    else{
                        $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Code_Cl = ? AND Commande.Ref_Comm = Concerner.Ref_Comm");
                        $req->execute(array($_SESSION['ID']));
                        while($res = $req->fetch()){
                            echo "<tr>".
                                "<td>".$res[0]."</td>".
                                "<td>".getProduitInfo($res[4],"Libelle")."</td>".
                                "<td>".$res[5]."</td>".
                                "<td>".$res[1]."</td>";
                            if(isRegle($res[0]) == false){
                                echo "<td>".
                                    "<a href='mCommande.php?token=".$_SESSION['ID']."&ref=".$res[4]."&old=".$res[5]."&com=".$res[0]."'><b class='fa fa-edit text-success mr-3'></b></a>".
                                    "<a href='../Traitement/Source/dcommand.php?ID=".$res[0]."'><b class='fa fa-trash-o text-danger'></b></a>".
                                    "</td>";
                            }
                            else{
                                echo "<td class='text-success'>Commande Regl&eacute;e</td>";
                            }
                            echo "</tr>";
                        }
                    }
                    ?>
                </table>
            </div>

            <div id="command" style="display:none;" class="mr-3 ml-3">
                <h4>Promotions</h4>
                <hr class="mr-5 ml-5 mt-3 mb-3">
                <div class="row" style="max-height: 500px; min-width: 100%; height: auto; overflow-x: auto">
                    <?php include_once '../Donnees/PHP/Lister.php'; listerPromotion();?>
                </div>
                <h4>Produits</h4>
                <hr class="mr-5 ml-5 mt-3 mb-3">
                <div class="row" style="max-height: 500px; min-width: 100%; height: auto; overflow-y: auto">
                    <?php include_once '../Donnees/PHP/Lister.php'; listerProduit();?>
                </div>
            </div>

        </center>


        <footer style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
            <center>
                <div>
                    <h4>Suivez et Likez-Nous</h4><br>
                    <a href="https://www.facebook.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-primary fa fa-facebook"></b></a>
                    <a href="https://www.twitter.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-info fa fa-twitter"></b></a>
                    <a href="https://plus.google.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-danger fa fa-google-plus"></b></a>
                    <a href=https://web.whatsapp.com" target="_blank" class="mr-0" style="padding: 5px;"><b class="text-success fa fa-whatsapp"></b></a>
                </div>
                <br>
                <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
            </center>
        </footer>
        <script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
        <script src="../Traitement/Script/eShop.js"></script>
        <script src="../Traitement/Script/eFont.js"></script>
        <script src="../Traitement/Script/Script.js"></script>
        <script src="../Traitement/Script/Espace.js"></script>
        <script>
            var sess_id = "<?=$_SESSION['ID'];?>";
            setInterval(function () {
                $.ajax({
                    type : "POST",
                    url : "../Traitement/Source/transaction.php",
                    data : {id : sess_id},
                    success : function(server_respond){
                        $("#trans").html(server_respond);
                    },
                });
                $.ajax({
                    type : "POST",
                    url : "../Traitement/Source/depense.php",
                    data : {id : sess_id},
                    success : function(server_respond){
                        $("#depens").html(server_respond + "XAF");
                    },
                });
            }, 500);
        </script>
    </body>
    </html>

<?php
}
else{
    header('location:../');
}
?>
