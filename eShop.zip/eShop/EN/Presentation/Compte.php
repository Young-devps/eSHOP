<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Account</title>
    <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Aide.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../Donnees/Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="../" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Back</a>
    </div>
</header>

<center>
    <div  style="display: none" id="decis"></div>
</center>

<center>
    <form id="form" class="text-dark ml-3" method="post" style="min-height: 400px; max-height: 400px">
        <center>
            <b id="form-legend" class="text-dark fa fa-user small" style="background-color: #fff;font-size: 14px; padding: 10px"></b><br>
            <h5>Compte <b class="logo">E</b>Shop</h5>
        </center>
        <center>
            <div id="group1">
                <div class="group">
                    <input type="text" class="input" name="nom" id="nom" required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="label">Name</label>
                </div>

                <div class="group">
                    <input type="text" name="addr" id="addr" class="input" required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="label">Address or Phone Number</label>
                </div>

                <div class="group">
                    <input type="text" name="vil" id="vil" class="input" required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="label">Town</label>
                </div>

                <div style="color: #fff; padding: 5px;">
                    <a href="../"><button type="button" class="btn btn-danger">Cancel <b class="fa fa-window-close"></b></button></a>
                    <button type="button" id="suiv" class="btn btn-success">Next <b class="fa fa-arrow-right"></b></button><br><br>
                </div>
            </div>
            <div id="group2" style="display: none;">
                <div class="group">
                    <input type="text" class="input" name="login" id="login" required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="label">Login</label>
                </div>

                <div class="group">
                    <input type="password" name="pass" id="pass" class="input" required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="label">Password</label>
                </div>
                <span class="text-muted small">At least 8 Caracters</span>

                <div style="color: #fff; padding: 5px;">
                    <button type="button" id="prev" class="btn btn-warning">Previous <b class="fa fa-arrow-left"></b></button>
                    <button type="button" id="sub" class="btn btn-success">Create <b class="fa fa-user-plus"></b></button><br><br>
                </div>
            </div>
        </center>
    </form>
</center>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , All rights reserved</span>
    </center>
</footer>
<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
<script>
    $('#suiv').click(function () {
        $('#group1').animate('slow', {left: '+50px'}).hide('slow');
        $('#group2').show('slow').addClass('fades');
    });
    $('#prev').click(function () {
        $('#group2').animate('slow', {left: '-50px'}).hide('slow');
        $('#group1').show('slow').addClass('fades');
    });
    $('#sub').click(function () {
        var inp = document.getElementById('pass').value.length;
        if(inp < 8){
            $('#decis').html("<div class='notif-error'>Mot de Passe trop Court</div>").addClass('fades').show('slow');
            setTimeout(function () {
                $('#decis').slideUp('slow');
            }, 2500);
        }
        else{
            let nom = $('#nom').val();
            let adr = $('#addr').val();
            let vil = $('#vil').val();
            let login = $('#login').val();
            let pass = $('#pass').val();
            $.ajax({
                type : "POST",
                url : "../Traitement/Source/ajoutCli.php",
                data : {nom: nom, adress: adr, ville: vil, login: login, code: pass},
                success : function(server_respond){
                    if(parseInt(server_respond) === 0){
                        $('#decis').html("<div class='notif-succes'>Compte Creer avec Success</div>").addClass('fades').show('slow');
                        setTimeout(function () {
                            $('#decis').slideUp('slow');
                            setTimeout(function () {
                                window.location.href = "../";
                            }, 3500);
                        }, 2500);
                    }
                    else{
                        $('#decis').html("<div class='notif-error'>Une Erreur s'est Produite</div>").addClass('fades').show('slow');
                        setTimeout(function () {
                            $('#decis').slideUp('slow');
                        }, 2500);
                    }
                },
                error : function () {
                    $('#decis').html("<div class='notif-error'>Une Erreur s'est Produite</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                },
            });
        }
    });
</script>
</body>
</html>
