<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
?>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
        <title>eShop: &Agrave; Propos</title>
        <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
        <link rel="stylesheet" href="../Presentation/Style/eFont.css">
        <link rel="stylesheet" href="../Presentation/Style/eShop.css">
        <link rel="stylesheet" href="../Presentation/Style/Aide.css">
    </head>
    <body>
    <header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
        <div class="text-lg-left">
            <center><img src="../Donnees/Fichier/favicone.png" width="50" height="50"><span  style="font-size:25px">
                <b class="logo">E</b>Shop <hr style="background: #fff;"><br></span></center>
            <a href="../" class="mr-5 text-white" style="padding: 5px;"><b class="text-danger fa fa-home"></b> Home</a>
            <a href="#" id="desc-link" class="mr-5 text-white" style="padding: 5px;"><b class="text-white fa fa-info"></b> Description</a>
            <a href="#" id="auth-link" class="mr-5 text-white" style="padding: 5px;"><b class="text-warning fa fa-users"></b> Authors</a>
            <a href="#" id="serv-link" class="mr-5 text-white" style="padding: 5px;"><b class="text-primary fa fa-bus"></b> Services</a>
            <a href="#" id="part-link" class="mr-5 text-white" style="padding: 5px;"><b class="text-success fa fa-users-cog"></b> Partners</a>
        </div>
    </header>

    <center style="max-height: 300px; min-height: 300px" id="desc" class="mb-5 mt-5">
        <h2>Brief Description</h2>
        <div class="d-inline-flex mb-2">
            <hr style="width: 350px;">
            <b class="fa fa-certificate test"></b>
            <hr style="width: 350px;">
        </div>

        <div class="cont mt-5 mb-5 fades">
            <b class="logo">E</b>Shop is a platform that allow you to buy your latest electronic tools at incredible prices.

        </div>
    </center>

    <center id="auth" style="max-height: 300px; min-height: 300px;display: none;" class="mb-3 mt-4 ml-3">
        <h2 class="fades">Authors</h2>
        <div class="d-inline-flex mb-2">
            <hr style="width: 350px;">
            <b class="fa fa-certificate test"></b>
            <hr style="width: 350px;">
        </div>

        <div class="row mt-3 mb-5">
            <div class="col badge text-white anime" style="background-color: #e3e3e3;">
                <img src="../Donnees/Fichier/male.png" class="rounded-circle border-primary" style="box-shadow:  0 0 0 2px #242424, 0 0 0 4px #009688" width="70" height="70"><br>
                <br><h3 class="text-dark">Boris SANDEU</h3><br>
                <i style="color: #a0a0a0;">Developer and Web Designer</i><br><br>
                <a href="https://www.twitter.com" target="_blank"><b class="text-info fa fa-twitter"></b></a> |
                <a href="https://www.linkedin.com" target="_blank"><b class="text-primary fa fa-linkedin"></b></a> |
                <a href="https://www.facebook.com" target="_blank"><b class="fa fa-facebook" style="color: #296698;"></b></a> |
                <a href="https://plus.google.com" target="_blank"><b class="text-danger fa fa-google-plus"></b></a> |
                <a href="https://www.youtube.com" target="_blank"><b class="fa fa-youtube" style="color: #ff0000;"></b></a>
            </div>
            <div class="col badge text-dark anime ml-2" style="background-color: #e3e3e3;">
                <img src="../Donnees/Fichier/female.png" class="rounded-circle border-primary" style="box-shadow:  0 0 0 2px #242424, 0 0 0 4px #009688" width="70" height="70"><br>
                <br><h3>Nathalie DJUIDJE</h3><br>
                <i style="color: #a0a0a0;">Web Designer</i><br><br>
                <a href="https://www.twitter.com" target="_blank"><b class="text-info fa fa-twitter"></b></a> |
                <a href="https://www.linkedin.com" target="_blank"><b class="text-primary fa fa-linkedin"></b></a> |
                <a href="https://www.facebook.com" target="_blank"><b class="fa fa-facebook" style="color: #296698;"></b></a> |
                <a href="https://plus.google.com" target="_blank"><b class="text-danger fa fa-google-plus"></b></a> |
                <a href="https://www.youtube.com" target="_blank"><b class="fa fa-youtube" style="color: #ff0000;"></b></a>
            </div>
            <div  style="background-color: #e3e3e3;" class="col badge text-dark anime ml-2">
                <img src="../Donnees/Fichier/female.png" class="rounded-circle border-primary" style="box-shadow:  0 0 0 2px #242424, 0 0 0 4px #009688" width="70" height="70"><br>
                <br><h3>KUITCHOU Joyce</h3><br>
                <i style="color: #a0a0a0;">Web Designer</i><br><br>
                <a href="https://www.twitter.com" target="_blank"><b class="text-info fa fa-twitter"></b></a> |
                <a href="https://www.linkedin.com" target="_blank"><b class="text-primary fa fa-linkedin"></b></a> |
                <a href="https://www.facebook.com" target="_blank"><b class="fa fa-facebook" style="color: #296698;"></b></a> |
                <a href="https://plus.google.com" target="_blank"><b class="text-danger fa fa-google-plus"></b></a> |
                <a href="https://www.youtube.com" target="_blank"><b class="fa fa-youtube" style="color: #ff0000;"></b></a>
            </div>
            <div style="background-color: #e3e3e3;" class="col badge text-dark anime ml-2 mr-3">
                <img src="../Donnees/Fichier/male.png" class="rounded-circle border-primary" style="box-shadow:  0 0 0 2px #242424, 0 0 0 4px #009688" width="70" height="70"><br>
                <br><h3>TIOGUE Junior</h3><br>
                <i style="color: #a0a0a0;">Web Developer</i><br><br>
                <a href="https://www.twitter.com" target="_blank"><b class="text-info fa fa-twitter"></b></a> |
                <a href="https://www.linkedin.com" target="_blank"><b class="text-primary fa fa-linkedin"></b></a> |
                <a href="https://www.facebook.com" target="_blank"><b class="fa fa-facebook" style="color: #296698;"></b></a> |
                <a href="https://plus.google.com" target="_blank"><b class="text-danger fa fa-google-plus"></b></a> |
                <a href="https://www.youtube.com" target="_blank"><b class="fa fa-youtube" style="color: #ff0000;"></b></a>
            </div>
        </div>
    </center>

    <center id="part" style="max-height: 300px; min-height: 300px;display: none;" class="mb-5 mt-5">
        <h2>Partners</h2>
        <div class="d-inline-flex mb-2">
            <hr style="width: 350px;">
            <b class="fa fa-certificate test"></b>
            <hr style="width: 350px;">
        </div>

        <div class="cont mt-5 mb-5 fades" style="border-right: 5px solid #009688;">
            <img src="../Donnees/Fichier/Jumia.jpg" class="rounded-circle" width="150" height="150">
        </div>
    </center>

    <center id="serv" style="max-height: 300px; min-height: 300px;display: none;" class="mb-5 mt-5">
        <h2>Our Services</h2>
        <div class="d-inline-flex mb-2">
            <hr style="width: 350px;">
            <b class="fa fa-certificate test"></b>
            <hr style="width: 350px;">
        </div>

        <div class="row">
            <div class="col">
                <b class="fa fa-truck img-thumbnail" style="font-size: 100px; color: #009688;border-bottom: 3px solid #009688"></b><br>
                <center>Home Deposite</center>
            </div>
            <div class="col">
                <b class="fa img-thumbnail" style="font-size: 100px; color: #009688;border-bottom: 3px solid #009688"></b><br>
                <center>Mobile Access</center>
            </div>
            <div class="col">
                <b class="fa fa-lock img-thumbnail" style="font-size: 100px; color: #009688;border-bottom: 3px solid #009688"></b><br>
                <center>Secure Account</center>
            </div>
            <div class="col">
                <b class="fa fa-money-bill img-thumbnail" style="font-size: 100px; color: #009688;border-bottom: 3px solid #009688"></b><br>
                <center>Mobile Payment</center>
            </div>
        </div>
    </center>

    <footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
        <center>
            <div>
                <h4>Follow and Like Us</h4><br>
                <a href="https://www.facebook.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-primary fa fa-facebook"></b></a>
                <a href="https://www.twitter.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-info fa fa-twitter"></b></a>
                <a href="https://plus.google.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-danger fa fa-google-plus"></b></a>
                <a href=https://web.whatsapp.com" target="_blank" class="mr-0" style="padding: 5px;"><b class="text-success fa fa-whatsapp"></b></a>
            </div>
            <br>
            <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , All rights reserved</span>
        </center>
    </footer>
    <script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
    <script src="../Traitement/Script/eShop.js"></script>
    <script src="../Traitement/Script/eFont.js"></script>
    <script src="../Traitement/Script/Aide.js"></script>
    </body>
</html>
