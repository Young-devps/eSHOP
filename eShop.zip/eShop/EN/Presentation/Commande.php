<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
session_start();
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Account</title>
    <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Aide.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../Donnees/Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="Espace.php?ID=<?=$_GET['token'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Back</a>
    </div>
</header>

<center>
    <div  style="display: none" id="decis"></div>
</center>

<center>
    <div style="border-radius: 5px; border: 1px solid #242424;" class="row ml-5 mt-5 mr-5">
        <div class="col">
            <center>
                <img src="../Donnees/Fichier/Data/<?=$_GET['ref'];?>.png" width="200" height="200" class="img-thumbnail">
                <hr class="ml-5 mr-5 bg-dark">
            </center>
            <b><?php include_once '../Donnees/PHP/Lister.php'; echo getProduitInfo($_GET['ref'], "Libelle"); ?></b><br>
            Price : <b class="text-primary"><?php include_once '../Donnees/PHP/Lister.php'; echo getProduitInfo($_GET['ref'], "Montant"); ?></b> XAF<br>
            Quantiy Disponible: <b class="text-success"><?php include_once '../Donnees/PHP/Lister.php'; echo getProduitInfo($_GET['ref'], "Quantite"); ?></b><br>
            <br>
            <?php if(isset($_GET['promo']) and $_GET['promo']=="on"):?>
                <strike class="badge badge-danger anim"><?php include_once '../Donnees/PHP/Lister.php'; echo getPromotion($_GET['ref'])?></strike>
            <?php endif; ?><br>
            <b class="fa fa-barcode" style="font-size: 100px"></b><br>
            <b id="pID"><?=$_GET['ref'];?></b>
        </div>
        <div class="col">
            <form id="form" class="text-dark ml-3" method="post" action="../Traitement/Source/command.php?ID=<?=$_GET['ref']?>" style="min-height: 350px; max-height: 350px">
                <center>
                    <b id="form-legend" class="text-dark fa fa-exchange-alt small" style="background-color: #fff;font-size: 14px; padding: 10px"></b><br>
                    <h5 class="mb-5">Command <b class="logo">E</b>Shop</h5>
                </center>
                <center>
                    <div id="group1">
                        <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
                            Client: <br>
                            <select name="client" class="mb-2 form-control-sm">
                                <?php
                                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                                    $req = $db->prepare( "SELECT Nom, Code_Cl FROM Client");
                                    $req->execute(array());
                                    while($res = $req->fetch()){
                                        echo "<option>".$res['Nom']."</option>";
                                    }
                                ?>
                            </select>
                        <?php endif; ?>
                        <div class="group">
                            <input type="number" name="qte" id="qte" class="input" required>
                            <span class="highlight"></span>
                            <span class="bar"></span>
                            <label class="label">Quantity</label>
                        </div>

                        <div style="color: #fff; padding: 5px;">
                            <a href="Espace.php?ID=<?=$_GET['token'];?>"><button type="button" id="prev" class="btn btn-warning">Precedent <b class="fa fa-arrow-left"></b></button></a>
                            <button type="button" id="sub" class="btn btn-success">Command <b class="fa fa-exchange-alt"></b></button><br><br>
                        </div>
                    </div>
                </center>
            </form>
        </div>
    </div>
</center>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , All rights reserved</span>
    </center>
</footer>
<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
<script>
    $('#sub').click(function () {
        let q = $('#qte').val();
        let p = $('#pID').html();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/cmdtest.php",
            data : {ID: p, QTE: q},
            success : function(server_respond){
                if(server_respond === "0"){
                    $('#decis').html("<div class='notif-succes'>Envoi de Commande</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#form').submit();
                    }, 2500);
                }
                else if(server_respond === "-1"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; Invalide</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
                else if(server_respond === "-2"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; N&eacute;gative</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
                else if(server_respond === "-3"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; Indisponible en Stock</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
            },
            error : function(server_respond) {
                $('#decis').html("<div class='notif-error'>Une erreur s'est produite</div>").addClass('fades').show('slow');
                setTimeout(function () {
                    $('#decis').slideUp('slow');
                }, 2500);
            },
        });
    });
</script>
</body>
</html>
