<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
session_start();
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Mon Compte</title>
    <link rel="shortcut icon" type="image/png" href="../Donnees/Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Espace.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../Donnees/Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="Espace.php?ID=<?=$_SESSION['ID'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Retour</a>
    </div>
</header>

<center>
    <div  style="display: none" id="decis"></div>
</center>

<center id="choix">
    <h4>CHOISIR LE MODE DE PAIEMENT</h4><br>
    <?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
        <hr class="mr-5 ml-5">
        <form id="f-norm" class="img-thumbnail" style="max-width: 350px" method="post" action="../Traitement/Source/reglement?c=<?=$_GET['com']?>&opt=null">
            <h5 class="mt-3">Paiement Sur Place</h3><br>
            <label>Montant &agrave; vers&eacute;</label>
            <input type="number" value="<?=$_GET['mnt'];?>" class="form-control" disabled>    
            <hr class="mr-5 ml-5">
            <button class="btn btn-success mb-1" onclick="$('#f-norm').submit();" type="button">Regler la Facture</button>
        </form>
    <?php endif; ?>
    <hr class="mr-5 ml-5">
    <br>
    <h5>Paiement Mobile</h3>
    <div class="row p-5" style="min-width: 100%; min-height: 250px; max-height: 250px">
        <div class="col">
            <img src="../Donnees/Fichier/mtn.jpg" width="120" height="120" class="img-thumbnail"><br>
            MTN Mobile Money
            <br><br>
            <button class="btn btn-warning btn-mtn" id="b-m" type="button">Regler</button>
        </div>
        <div class="col">
            <img src="../Donnees/Fichier/nexttel.png" width="100" height="100" class="img-thumbnail"><br>
            NEXTTEL Possa
            <br><br>
            <button class="btn btn-danger btn-nex" id="b-n" type="button">Regler</button>
        </div>
        <div class="col">
            <img src="../Donnees/Fichier/orange.png" width="125" height="125" class="img-thumbnail"><br>
            ORANGE Money
            <br><br>
            <button class="btn btn-orange" id="b-o" type="button">Regler</button>
        </div>
        <div class="col">
            <img src="../Donnees/Fichier/eu.png" width="100" height="100" class="img-thumbnail"><br>
            EXPRESS UNION Mobile Money
            <br><br>
            <button class="btn btn-eu" id="b-e" type="button">Regler</button>
        </div>
    </div>
</center>

<center style="min-height: 430px; max-height: 430px">
    <form class="p5 m-5 img-thumbnail border-dark" id="mtn-f" method="post" action="../Traitement/Source/reglement?c=<?=$_GET['com']?>&opt=mtn" style="max-width: 500px">
        <header class="bg-warning text-dark p-2 mb-3">
            <h5>Reglement MTN Mobile Money</h5>
        </header>
        <img src="../Donnees/Fichier/mtn.jpg" width="100" height="100" class="img-thumbnail"><br>
        <label for="N-mtn">Votre Numero de T&eacute;l&eacute;phone</label>
        <input id="N-mtm" type="number" maxlength="9" name="number-mtn" class="form-control">
        <label for="mtn-prix">Montant &agrave; d&eacute;di&eacute;</label>
        <input id="mtn-prix" type="number" name="prixmtn" value="<?=$_GET['mnt'];?>" class="form-control" disabled>
        <span id="text-mtn" class="small text-muted">
            <u>Format</u><br>
            67XXXXXXX  |  68XXXXXXX  |  65XXXXXXX
        </span>
        <hr class="mr-5 ml-5">
        <button class="btn btn-warning btn-mtn" type="button"  id="sub-mtn">Regler la Facture</button>
        <button class="btn btn-outline-warning text-dark b-anul btn-mtn" type="button">Changer le Mode de Paiement</button>
    </form>
    <form class="p5 m-5 img-thumbnail border-dark" id="nex-f" method="post" action="../Traitement/Source/reglement?c=<?=$_GET['com']?>&opt=nexttel" style="max-width: 500px">
        <header class="bg-danger text-white p-2 mb-3">
            <h5>Reglement NEXTTEL Possa</h5>
        </header>
        <img src="../Donnees/Fichier/nexttel.png" width="100" height="100" class="img-thumbnail"><br>
        <label for="N-nex">Votre Numero de T&eacute;l&eacute;phone</label>
        <input id="N-nex" type="number" maxlength="9" class="form-control">
        <label for="nex-prix">Montant &agrave; d&eacute;di&eacute;</label>
        <input id="nex-prix" type="number" value="<?=$_GET['mnt'];?>" class="form-control" disabled>
        <span id="text-nex" class="small text-muted">
            <u>Format</u><br>
            66XXXXXXX<br>
        </span>
        <hr class="mr-5 ml-5">
        <button id="sub-nex" class="btn btn-danger btn-mtn" type="button">Regler la Facture</button>
        <button class="btn btn-outline-danger b-anul btn-mtn" type="button">Changer le Mode de Paiement</button>
    </form>
    <form class="p5 m-5 img-thumbnail border-dark" id="ora-f" method="post" action="../Traitement/Source/reglement?c=<?=$_GET['com']?>&opt=orange" style="max-width: 500px">
        <header class="text-white p-2 mb-3" style="background: #FF6600">
            <h5>Reglement ORANGE Money</h5>
        </header>
        <img src="../Donnees/Fichier/orange.png" width="100" height="100" class="img-thumbnail"><br>
        <label for="N-ora">Votre Numero de T&eacute;l&eacute;phone</label>
        <input id="N-ora" type="number" maxlength="9" class="form-control">
        <label for="ora-prix">Montant &agrave; d&eacute;di&eacute;</label>
        <input id="ora-prix" type="number" value="<?=$_GET['mnt'];?>" class="form-control" disabled>
        <span id="text-ora" class="small text-muted">
            <u>Format</u><br>
            69XXXXXXX  |  65XXXXXXX
        </span>
        <hr class="mr-5 ml-5">
        <button id="sub-ora" class="btn btn-orange" type="button">Regler la Facture</button>
        <button class="btn btn-outline-orange b-anul btn-mtn" type="button">Changer le Mode de Paiement</button>
    </form>
    <form class="p5 m-1 img-thumbnail border-dark" id="eu-f" method="post" action="../Traitement/Source/reglement?c=<?=$_GET['com']?>&opt=eu" style="max-width: 500px">
        <header class="text-white p-2 mb-3" style="background-color: rgb(0,0,160);">
            <h5>Reglement EU Mobile Money</h5>
        </header>
        <img src="../Donnees/Fichier/eu.png" width="100" height="100" class="img-thumbnail"><br>
        <label for="N-eu">Votre Numero de T&eacute;l&eacute;phone</label>
        <input id="N-eu" type="number" maxlength="9" class="form-control">
        <label for="eu-prix">Montant &agrave; d&eacute;di&eacute;</label>
        <input id="eu-prix" type="number" value="<?=$_GET['mnt'];?>" class="form-control" disabled>
        <span id="text-eu" class="small text-muted">
            <u>Format</u><br>
            67XXXXXXX  |  68XXXXXXX  |  69XXXXXXX  |  65XXXXXXX
            <br>
            22XXXXXXX  |  23XXXXXXX  |  66XXXXXXX
        </span>
        <hr class="mr-5 ml-5">
        <button id="sub-eu" class="btn btn-eu" type="button">Regler la Facture</button>
        <button class="btn btn-outline-eu b-anul btn-mtn" type="button">Changer le Mode de Paiement</button>
    </form>
</center>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
    </center>
</footer>
<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
<script>
    $('#b-o').click(function () {
        $("#choix").css({'display': 'none'});
        $("#mtn-f").css({'display': 'none'});
        $("#eu-f").css({'display': 'none'});
        $("#nex-f").css({'display': 'none'});
        $("#ora-f").show('slow');
    });
    $('#b-n').click(function () {
        $("#choix").css({'display': 'none'});
        $("#mtn-f").css({'display': 'none'});
        $("#eu-f").css({'display': 'none'});
        $("#ora-f").css({'display': 'none'});
        $("#nex-f").show('slow');
    });
    $('#b-m').click(function () {
        $("#choix").css({'display': 'none'});
        $("#ora-f").css({'display': 'none'});
        $("#eu-f").css({'display': 'none'});
        $("#nex-f").css({'display': 'none'});
        $("#mtn-f").show('slow');
    });
    $('.b-anul').click(function () {
        $("#eu-f").css({'display': 'none'});
        $("#mtn-f").css({'display': 'none'});
        $("#ora-f").css({'display': 'none'});
        $("#nex-f").css({'display': 'none'});
        $("#choix").show('slow');
    });
    $('#b-e').click(function () {
        $("#choix").css({'display': 'none'});
        $("#mtn-f").css({'display': 'none'});
        $("#ora-f").css({'display': 'none'});
        $("#nex-f").css({'display': 'none'});
        $("#eu-f").show('slow');
    });
</script>
<script>
    $('#sub').click(function () {
        let q = $('#qte').val();
        let p = $('#pID').html();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/cmdtest.php",
            data : {ID: p, QTE: q},
            success : function(server_respond){
                if(server_respond === "0"){
                    $('#decis').html("<div class='notif-succes'>Envoi de Commande</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#form').submit();
                    }, 2500);
                }
                else if(server_respond === "-1"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; Invalide</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
                else if(server_respond === "-2"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; N&eacute;gative</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
                else if(server_respond === "-3"){
                    $('#decis').html("<div class='notif-error'>Quantit&eacute; Indisponible en Stock</div>").addClass('fades').show('slow');
                    setTimeout(function () {
                        $('#decis').slideUp('slow');
                    }, 2500);
                }
            },
            error : function(server_respond) {
                $('#decis').html("<div class='notif-error'>Une erreur s'est produite</div>").addClass('fades').show('slow');
                setTimeout(function () {
                    $('#decis').slideUp('slow');
                }, 2500);
            },
        });
    });
</script>
<script>
    $('#N-mtm').keyup(function () {
        let n = $('#N-mtm').val();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/mtn.php",
            data : {mtn : n},
            success : function(server_respond){
                $("#text-mtn").html(server_respond);
            },
        });
    });
    $('#N-nex').keyup(function () {
        let n = $('#N-nex').val();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/nexttel.php",
            data : {next : n},
            success : function(server_respond){
                $("#text-nex").html(server_respond);
            },
        });
    });
    $('#N-ora').keyup(function () {
        let n = $('#N-ora').val();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/orange.php",
            data : {ora : n},
            success : function(server_respond){
                $("#text-ora").html(server_respond);
            },
        });
    });
    $('#N-eu').keyup(function () {
        let n = $('#N-eu').val();
        $.ajax({
            type : "POST",
            url : "../Traitement/Source/eu.php",
            data : {eu : n},
            success : function(server_respond){
                $("#text-eu").html(server_respond);
            },
        });
    });
</script>
<script>
    $('#sub-mtn').click(function () {
       let ok = $('#text-mtn').text();
       if(ok === "OK"){
           $('#mtn-f').submit();
       }
    });
    $('#sub-nex').click(function () {
        let ok = $('#text-nex').text();
        if(ok === "OK"){
            $('#nex-f').submit();
        }
    });
    $('#sub-ora').click(function () {
        let ok = $('#text-ora').text();
        if(ok === "OK"){
            $('#ora-f').submit();
        }
    });
    $('#sub-eu').click(function () {
        let ok = $('#text-eu').text();
        if(ok === "OK"){
            $('#eu-f').submit();
        }
    });
</script>
</body>
</html>
