<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 PM
 */

function CodeClient(){
    $link = mysqli_connect('localhost', 'root', '', 'Gestion');
    do{
        $code = "E-";
        for($i = 0 ; $i < 5; $i++){
            $code = $code.mt_rand(0, 9);
        }
        $q = mysqli_query($link, "SELECT * FROM Client WHERE Code_Cl = $code");
        $r = 0;
        if($q){
            $r = mysqli_num_rows($q);
        }
    }while($r != 0);
    return $code;
}

function CodeProduit(){
    $link = mysqli_connect('localhost', 'root', '', 'Gestion');
    do{
        $code = "PR-";
        for($i = 0 ; $i < 13; $i++){
            $code = $code.mt_rand(0, 9);
        }
        $q = mysqli_query($link, "SELECT * FROM Produit WHERE Ref_Prod = $code");
        $r = 0;
        if($q){
            $r = mysqli_num_rows($q);
        }
    }while($r != 0);
    return $code;
}

function CodeLivraison(){
    $link = mysqli_connect('localhost', 'root', '', 'Gestion');
    do{
        $code = "LIV-";
        for($i = 0 ; $i < 10; $i++){
            $code = $code.mt_rand(0, 9);
        }
        $q = mysqli_query($link, "SELECT * FROM Livraison WHERE Ref_Liv = $code");
        $r = 0;
        if($q){
            $r = mysqli_num_rows($q);
        }
    }while($r != 0);
    return $code;
}

function CodeCommande(){
    $link = mysqli_connect('localhost', 'root', '', 'Gestion');
    do{
        $code = "CM-";
        for($i = 0 ; $i < 10; $i++){
            $code = $code.mt_rand(0, 9);
        }
        $q = mysqli_query($link, "SELECT * FROM Commande WHERE Ref_Comm = $code");
        $r = 0;
        if($q){
            $r = mysqli_num_rows($q);
        }
    }while($r != 0);
    return $code;
}

?>