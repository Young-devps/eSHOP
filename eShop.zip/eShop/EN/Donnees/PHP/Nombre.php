<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/7/2019
 * Time: 5:41 PM
 */
    function CompteLigneTable($table){
        $db = mysqli_connect('localhost', 'root', '', 'Gestion') or die("Erreur 502");
        $req = mysqli_query($db, "SELECT * FROM $table");
        return mysqli_num_rows($req);
    }

    function NbreCommande($id){
        $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
        $req = $db->prepare( "SELECT * FROM Commande, Reglement WHERE Code_Cl = ? AND NOT Commande.Ref_Comm == Reglement.Ref_Comm");
        $req->execute(array($id));
        return $req->rowCount();
    }
?>