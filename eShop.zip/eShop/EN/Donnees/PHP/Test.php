<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 3:19 AM
 */
function isClient($param){
    $lnk = mysqli_connect('localhost', 'root', '', 'Gestion');
    $q = mysqli_query($lnk, "SELECT * FROM Client WHERE Nom = $param");
    if($q){
        if(mysqli_num_rows($q) != 0){
            return true;
        }
        else{
            return false;
        }
    }
    else{
        return false;
    }
}

function isAuthentify($login, $pass){
    $pas = sha1($pass);
    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
    $rq = $bdd->prepare("SELECT * FROM Utilisateur WHERE Login = ? AND Code = ?");
    $rq->execute(array($login, $pas));
    if($rq->rowCount() != 0){
        return true;
    }
    else{
        return false;
    }
}

?>