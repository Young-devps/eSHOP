<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 1:04 PM
 */
    function getProfil($id, $opt, $champ){
        if($opt == 0){
            $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
            $req = $db->prepare( "SELECT * FROM Client WHERE Code_Cl = ?");
            $req->execute(array($id));
            $res = $req->fetch();
            return $res[$champ];
        }
        else{
            $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
            $req = $db->prepare( "SELECT * FROM Utilisateur WHERE eID = ?");
            $req->execute(array($id));
            $res = $req->fetch();
            return $res[$champ];
        }
    }
?>