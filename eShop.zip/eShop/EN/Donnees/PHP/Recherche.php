<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 4:15 AM
 */

function rechercheProduit($ind){
    $link = mysqli_connect('localhost', 'root', '', 'Gestion');
    $rq = mysqli_query($link, "SELECT * FROM Produit WHERE Libelle like '%".$ind."%'");
    return $rq;
}

?>