<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 3:25 AM
 */

include_once 'Test.php';

function Ajout($option, $tab){
    if($option == "CLI"){
            if(isClient($tab[1]) == true){
                return false;
            }
            else{
                $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
                $rq = $bdd->prepare("INSERT INTO Client(Code_CL, Nom, Adresse, Ville) VALUES(?, ?, ?, ?)");
                $rq->execute(array($tab[0], $tab[1], $tab[2], $tab[3]));
                $rq = $bdd->prepare("INSERT INTO Utilisateur(eID, Type, Login, Code) VALUES(?, ?, ?, ?)");
                $rq->execute(array($tab[0], $tab[4], $tab[5], $tab[6]));
                return true;
            }
        }
    if($option == "PROD"){
                $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
                $rq = $bdd->prepare("INSERT INTO Produit(Ref_Prod, Libelle, Montant, Quantite) VALUES(?, ?, ?, ?)");
                $rq->execute(array($tab[0], $tab[1], $tab[2], $tab[3]));
                return true;
            }
}

?>