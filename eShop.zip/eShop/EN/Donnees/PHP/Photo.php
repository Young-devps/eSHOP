<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 1:04 PM
 */

function maPhoto($id){
    if(file_exists("../Fichier/User/$id.png") == true){
        echo "<img src='../Fichier/User/$id.png' class='profil' width='75' height='75'>";
    }
    elseif (file_exists("../Fichier/User/$id.jpg") == true){
        echo "<img src='../Fichier/User/$id.png' class='profil' width='75' height='75'>";
    }
    else{
        echo "<b class='fa fa-user text-white rounded-circle' style='font-size: 25px; padding: 15px; border: 5px solid white; width: 75px; height: 75px;'></b>";
    }
}

?>