<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/7/2019
 * Time: 5:34 PM
 */

function gProduit($id, $champ){
    $db = mysqli_connect('localhost', 'root', '', 'Gestion') or die("Erreur 502");
    $req = mysqli_query($db, "SELECT * FROM Produit");
    $tab = array();
    $i = 0;
    if($req){
        while($data = mysqli_fetch_assoc($req)){
            $tab[$i]['ID'] =  $data['Ref_Prod'];
            $tab[$i]['Nom'] = $data['Libelle'];
            $tab[$i]['Qte'] = $data['Quantite'];
            $tab[$i]['PU'] = $data['Montant'];
            $i = $i + 1;
        }
        return $tab[$id][$champ];
    }
}

function gPromotion($id, $champ){
    $db = mysqli_connect('localhost', 'root', '', 'Gestion') or die("Erreur 502");
    $req = mysqli_query($db, "SELECT * FROM Promotion");
    $tab = array();
    $i = 0;
    if($req){
        while($data = mysqli_fetch_assoc($req)){
            $tab[$i]['ID'] =  $data['Ref_Prod'];
            $tab[$i]['aPrix'] = $data['aPrix'];
            $tab[$i]['nPrix'] = $data['nPrix'];
            $i = $i + 1;
        }
        return $tab[$id][$champ];
    }
}

?>