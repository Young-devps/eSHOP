<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
	<title>eShop: La Boutique de Reference</title>
	<link rel="shortcut icon" type="image/png" href="../Fichier/favicone.png">
	<link rel="stylesheet" href="Presentation/Style/eFont.css">
    <link rel="stylesheet" href="Presentation/Style/eShop.css">
    <link rel="stylesheet" href="Presentation/Style/Style.css">
</head>
<body>
    <header id="head">
        <div class="d-inline">
            <div class="text-sm-left mb-5">
                <a href="#" class="text-light small  mr-2"><b class="text-muted">Tel: </b>+237 (651) 796 157  <b class="text-warning fa fa-phone"></b></a>
                |<a class="ml-2 text-light small" id="em"><b class="text-muted">Email: </b>info@eshop.com</a> <b class="text-danger fa fa-at"></b>
            </div>
            <div class="ml-5 text-sm-right small b-right">
                <b class="text-muted">Location</b> : <i class="anim fa fa-map-marker text-success"></i> IUT Fotso Victor, Bandjoun(<img src="Donnees/Fichier/cm.png" width="15" height="15"/>)<b></b>
            </div>
        </div>
        <center>
            <div class="d-inline-flex">
                <img src="../Fichier/1f4b4.png" class="anim h-img mr-5 rounded-circle"/>
                <h2><b class="logo">E</b>-Shop</h2>
                <img src="../Fichier/1f4b6.png" class="anim h-img ml-5 rounded-circle"/>
            </div>
            <hr style="background: #fff; width: 500px">
            <h4 style="color: #757575;">La Boutique de Reference</h4>
        </center>
        <hr style="background-color: #505050;">
        <div class="text-sm-left small d-inline-flex">
            <a href="Presentation/Compte.php" class="btn-sm text-white"><b class="fa fa-user-plus text-primary"></b> Inscription</a> <b style="font-size: 20px">| </b>
            <div class="dropdown">
                <button class="btn-sm text-white btn-dark dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Langue <img src="../Fichier/french.png" width="10" height="10">
                </button>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                    <a class="dropdown-item" href="#"><img src="../Fichier/french.png" width="10" height="10"> Fran&ccedil;ais</a>
                    <a class="dropdown-item" href="../EN/"><img src="../Fichier/english.png" width="10" height="10"> Anglais</a>
                </div>
            </div> <b style="font-size: 20px">| </b>
            <a href="Presentation/About.php" class="btn-sm text-white">&Agrave; Propos</a>
        </div>
        <div class="text-sm-right small s-block">
            <button type="button" id="b-search" class="btn-search btn-sm btn-success border-0">🔎 Rechercher</button>
        </div>
    </header>
    <div class="row" style="padding: 3px">
        <div class="col-6">
            <form id="form" class="text-dark ml-3" method="post" action="Presentation/Espace.php">
                <center>
                    <b id="form-legend" class="text-dark fa fa-user small" style="background-color: #fff;font-size: 14px; padding: 10px"></b><br>
                    <h5>Connexion</h5>
                    <br>
                    <div class="notif-error mb-lg-5" style="display: none;"></div>
                </center>
                <center>
                    <div>
                        <div class="group">
                            <input type="text" class="input" name="login" id="login" required>
                            <span class="highlight"></span>
                            <span class="bar"></span>
                            <label class="label">Login</label>
                        </div>

                        <div class="group">
                            <input type="password" name="pass" id="pass" class="input" required>
                            <span class="highlight"></span>
                            <span class="bar"></span>
                            <label class="label">Mot de Passe</label>
                        </div>

                        <div style="color: #fff; padding: 5px;">
                            <button type="button" id="conn" class="btn btn-success">Me Connecter</button><br><br>
                        </div>
                    </div>
                </center>
            </form>
        </div>
        <div class="col-6">
            <fieldset id="field">
                <legend>Nos Produits</legend>
                <div class="row mb-3 mt-3">
                    <div class="prod col ml-lg-5" id="1">1</div>
                    <div class="prod col" id="2">2</div>
                    <div class="prod col" id="3">3</div>
                </div>
            </fieldset>
            <fieldset id="f-search">
                <legend>Recherche</legend>
                <form>
                    <center>
                        <div class="form-group mt-5">
                            <div class="form-label-group">
                                Recherche<br><br>
                                <input type="search" id="rech" class="form-control-sm" placeholder="Entrez le Nom du Produit"><br><br>
                                <button type="button" class="btn btn-danger" id="res"><b class="fa fa-window-close"></b> Annuler</button>
                            </div>
                        </div>
                    </center>
                    <hr class="mr-5 ml-3">
                    <div id="result">

                    </div>
                </form>
            </fieldset>
        </div>
    </div>
    <footer style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
        <center>
            <form method="post" action="Traitement/Source/email.php">
                <h5>Abonnement &agrave; notre Newsletter</h5>
                <input type="text" name="mail" class="input text-white" placeholder="Entrez Votre Adresse Electronique"><br>
                <span class="text-muted">Vous recevrez toutes nos dernieres produits et nos promotions par mail</span><br>
                <button type="submit" id="news" class="btn btn-warning">M'inscrire</button><br><br>
            </form>
            <hr class="dropdown-divider ml-7 mr-7 bg-white">
            <div>
                <h4>Suivez et Likez-Nous</h4><br>
                <a href="https://www.facebook.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-primary fa fa-facebook"></b></a>
                <a href="https://www.twitter.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-info fa fa-twitter"></b></a>
                <a href="https://plus.google.com" target="_blank" class="mr-5" style="padding: 5px;"><b class="text-danger fa fa-google-plus"></b></a>
                <a href=https://web.whatsapp.com" target="_blank" class="mr-0" style="padding: 5px;"><b class="text-success fa fa-whatsapp"></b></a>
            </div>
            <br>
            <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
        </center>
    </footer>
    <script src="Traitement/Script/jquery-3.3.1.min.js"></script>
    <script src="Traitement/Script/eShop.js"></script>
    <script src="Traitement/Script/eFont.js"></script>
    <script src="Traitement/Script/Script.js"></script>
    <script>
        $('#conn').click(function () {
            let login = $('#login').val();
            let code = $('#pass').val();
            $.ajax({
                type : "POST",
                url : "Traitement/Source/connexion.php",
                data : {login: login, code: code},
                success : function(server_respond){
                    if(server_respond == 0){
                        $('#form').submit();
                    }
                    else if(server_respond == -1){
                        $(".notif-error").html("Authentification Incorrecte").show('slow');
                        setTimeout(function () {
                            $('.notif-error').slideUp('slow');
                        }, 2500);
                    }
                },
                error : function () {
                    $(".notif-error").html("Une Erreur s'est Produite").show('slow');
                    setTimeout(function () {
                        $('.notif-error').slideUp('slow');
                    }, 2500);
                }
            });
        });
        $(document).ready(function () {
            $('#rech').keyup(function () {
                var len = document.getElementById('rech').value.length;
                var ind = $('#rech').val();
                if(len > 2){
                    $.ajax({
                        type : "POST",
                        url : "Traitement/Source/recherche.php",
                        data : {indice: ind},
                        success : function(server_respond){
                            $("#result").html("<center>" + server_respond + "</center>");
                        },
                    });
                }
                else{
                    $("#result").html("");
                }
            });
            for (let i = 1; i < 4; i++) {
                $.ajax({
                    type : "POST",
                    url : "Traitement/Source/liste.php",
                    data : null,
                    success : function(server_respond){
                        $("#"+i).html(server_respond);
                    },
                });
            }
        });
        setInterval(function () {
            for (let i = 1; i < 4; i++) {
                $.ajax({
                    type : "POST",
                    url : "Traitement/Source/liste.php",
                    data : null,
                    success : function(server_respond){
                        $("#"+i).html(server_respond);
                    },
                });
            }
        }, 5000);
    </script>
</body>
</html>