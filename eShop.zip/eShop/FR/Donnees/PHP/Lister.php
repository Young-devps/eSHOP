<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/9/2019
 * Time: 2:59 PM
 */

function listerPromotion(){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM  Produit, Promotion WHERE Promotion.Ref_Prod = Produit.Ref_Prod");
    $req->execute(array());
    while($res = $req->fetch()){
        echo "<div class='col-lg-1 ml-5 mr-5 mb-5 mt-5' style='min-width: 350px'>".
             "<img src='../../Fichier/Data/".$res['Ref_Prod'].".png' width='75' class='img-thumbnail' height='75'><br>"
            ."<span class='small'>".$res['Libelle']."</span><br>".
            "PU :<span class='small text-success'>".$res['Montant']." XAF (<strike class='badge badge-danger'>".$res['nPrix']." XAF</strike>)</span><br>".
            "<a href='../Presentation/Commande.php?token=".$_SESSION['ID']."&ref=".$res['Ref_Prod']."&promo=on'><button class='btn btn-cmd btn-success mt-2'><b class='fa fa-shopping-basket'></b> Commander</button></a><br>".
            "</div>";
    }
}

function listerProduit(){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM  Produit");
    $req->execute(array());
    $i = 0;
    while($res = $req->fetch()){
        echo "<div class='small col-lg-1 ml-5 mr-5 mb-5 mt-5' style='min-width: 150px'>".
            "<img src='../../Fichier/Data/".$res['Ref_Prod'].".png' width='70' class='rounded-circle' height='70'><br>"
            ."<span class='small'>".$res['Libelle']."</span><br>".
            "PU :<span class='small text-primary'>".$res['Montant']." XAF</span>".
            "<center>".
            "<a href='../Presentation/Commande.php?token=".$_SESSION['ID']."&ref=".$res['Ref_Prod']."&promo=on'>".
            "<button class='btn btn-primary mt-2 mr-2'><b class='fa fa-shopping-cart'></b>Commander</button></a></center><br>".
            "</div>";
        $i = $i + 1;
    }
}

function getProduitInfo($id, $champ){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Produit WHERE Ref_Prod = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res[$champ];
}

function getPromotion($id){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Promotion WHERE Ref_Prod = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res['nPrix'];
}

function getClientInfo($id, $champ){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Client WHERE Code_Cl = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res[$champ];
}

function gClientCode($id){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Commande WHERE Ref_Comm = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res["Code_Cl"];
}

function gProduitRef($id){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Concerner WHERE Ref_Comm = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res["Ref_Prod"];
}

function Concerner($id, $champ){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Concerner WHERE Ref_Comm = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res[$champ];
}

function Commande($id, $champ){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Commande WHERE Ref_Comm = ?");
    $req->execute(array($id));
    $res = $req->fetch();
    return $res[$champ];
}

function isRegle($idComm){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Reglement WHERE Ref_Comm = ?");
    $req->execute(array($idComm));
    if($req->rowCount() == 0){
        return false;
    }
    else{
        return true;
    }
}

function isLivre($idComm){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare( "SELECT * FROM Livraison WHERE Ref_Comm = ?");
    $req->execute(array($idComm));
    if($req->rowCount() == 0){
        return false;
    }
    else{
        return true;
    }
}

function isAdmin($idCli){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare("SELECT * FROM Utilisateur WHERE (eID = ? AND Type = 'U')");
    $req->execute(array($idCli));
    if($req->rowCount() == 0){
        return false;
    }
    else{
        return true;
    }
}

function isCompte($idCli){
    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
    $req = $db->prepare("SELECT * FROM Utilisateur WHERE eID = ?");
    $req->execute(array($idCli));
    if($req->rowCount() == 0){
        return true;
    }
    else{
        return false;
    }
}
?>