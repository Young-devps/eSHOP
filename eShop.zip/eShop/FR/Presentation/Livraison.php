<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
session_start();
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Mon Compte</title>
    <link rel="shortcut icon" type="image/png" href="../../Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Espace.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../../Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="Espace.php?ID=<?=$_SESSION['ID'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Retour</a>
    </div>
</header>

<table>
    <tr class="t-head"><td>Ref&eacute;rence Commande</td><td>Client</td><td>Produit(Quantite Command&eacute;e)</td><td>Montant Total Pay&eacute;</td><td>Date de Reglement</td><td>Action</td></tr>
    <?php
        include_once "../Donnees/PHP/Lister.php";
        $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
        $req = $db->prepare( "SELECT * FROM Reglement, Commande, Concerner WHERE Commande.Ref_Comm = Concerner.Ref_Comm AND Commande.Ref_Comm = Reglement.Ref_Comm");
        $req->execute(array());
        while($res = $req->fetch()){
            echo "<tr><td>".$res[0]."</td><td>".getClientInfo($res[1], "Nom")."</td><td>".getProduitInfo($res[8], "Libelle")."(<b class='text-primary'>".$res[9]."</b>)".
                "</td><td><i class='text-info'>$res[3]</i> XAF</td><td>$res[2]</td>";
            if(isLivre($res[0]) == true){
                echo "<td><b class='text-success fa fa-check-circle'></b> D&eacute;j&agrave; Livr&eacute; </td>";
            }
            else{
                echo "<td><a href='../Traitement/Source/livrer.php?com=".$res[0]."'><button class='btn btn-warning'><b class='fa fa-truck'></b> Livrer </button></a></td>";
            }
            echo "</tr>";
        }
    ?>
</table>
<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
    </center>
</footer>

<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
</body>
</html>
