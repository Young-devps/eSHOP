<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Mon Compte</title>
    <link rel="shortcut icon" type="image/png" href="../../Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Espace.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../../Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="Espace.php?ID=<?php session_start(); echo $_SESSION['ID'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Retour</a>
    </div>
</header>

<?php if(isset($_SESSION['Type']) and $_SESSION['Type'] == "A"):?>
    <center>
        <?php if(isset($_GET['liste']) and $_GET['liste'] == "pr"):?>
            <section>
                <table>
                    <tr class="t-head"><td>Produit</td>
                        <td>Prix Unitaire</td>
                        <td>Quantit&eacute;</td></tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Produit");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res['Libelle']."</td><td>".$res['Montant']."</td><td class='td'>".$res['Quantite']."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php if(isset($_GET['liste']) and $_GET['liste'] == "cl"):?>
            <section>
                <table>
                    <tr class="t-head"><td>Code du Client</td>
                        <td>Nom</td>
                        <td>Adresse(Ville de Residence)</td></tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Client");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td class='text-primary'>".$res['Code_Cl']."</td><td>".$res['Nom']."</td><td>".$res['Adresse']."(".$res['Ville'].")</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php if(isset($_GET['liste']) and $_GET['liste'] == "li"):?>
            <section>
                <table class="mt-2">
                    <tr class="t-head">
                        <td>Reference de Livraison</td>
                        <td>Reference de Commande</td>
                        <td>Client (Adresse - Ville)</td>
                        <td>Produit (Quantit&eacute;)</td>
                    </tr>
                    <?php
                    include_once '../Donnees/PHP/Lister.php';

                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Livraison, Commande, Concerner WHERE Livraison.Ref_Comm = Commande.Ref_Comm AND Concerner.Ref_Comm = Commande.Ref_Comm");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td class='text-primary'>".$res[0]."</td><td>".$res[1]."</td>".
                            "<td>".getClientInfo($res[4],"Nom")."(".getClientInfo($res[4], "Adresse")." - ".getClientInfo($res[4], "Ville").")</td>".
                            "<td>".getProduitInfo($res[6], "Libelle")." [".$res[7]."]</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php include_once '../Donnees/PHP/Lister.php'; if(isset($_GET['liste']) and $_GET['liste'] == "cm"):?>
            <section>
                <table>
                    <tr class="t-head">
                        <td>Reference</td>
                        <td>Produit</td>
                        <td>Quantit&eacute;</td>
                        <td>Client</td>
                        <td>Date</td>
                    </tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Commande.Ref_Comm = Concerner.Ref_Comm");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res[0]."</td><td>".getProduitInfo($res[4], "Libelle")."</td><td class='td'>".$res[5]."</td>".
                            "<td>".getClientInfo($res[2], "Nom")."</td><td>".$res[1]."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php include_once '../Donnees/PHP/Lister.php'; if(isset($_GET['liste']) and $_GET['liste'] == "fa"):?>
            <section>
                <table>
                    <tr class="t-head">
                        <td>Numero Facture</td>
                        <td>Produit</td>
                        <td>Quantit&eacute;</td>
                        <td>Client</td>
                        <td>Montant Pay&eacute;</td>
                        <td>Date de Reglement</td>
                    </tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Commande, Concerner, Reglement WHERE Commande.Ref_Comm = Concerner.Ref_Comm AND Commande.Ref_Comm = Reglement.Ref_Comm");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res[0]."-".$res[2]."</td><td>".getProduitInfo($res[4], "Libelle")."</td><td class='td'>".$res[5]."</td>".
                            "<td>".getClientInfo($res[2], "Nom")."</td><td>".$res[9]."</td><td>".$res[8]."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
    </center>
<?php endif; ?>

<?php if(!isset($_SESSION['Type']) or $_SESSION['Type'] != "A"):?>
    <center>
        <?php if(isset($_GET['liste']) and $_GET['liste'] == "li"):?>
            <section>
                <table class="mt-2">
                    <tr class="t-head">
                        <td>Reference de Livraison</td>
                        <td>Reference de Commande</td>
                        <td>Client (Adresse - Ville)</td>
                        <td>Produit (Quantit&eacute;)</td>
                    </tr>
                    <?php
                    include_once '../Donnees/PHP/Lister.php';

                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Livraison, Commande, Concerner WHERE Commande.Code_Cl = ? AND Livraison.Ref_Comm = Commande.Ref_Comm AND Concerner.Ref_Comm = Commande.Ref_Comm");
                    $req->execute(array($_SESSION['ID']));
                    while($res = $req->fetch()){
                        echo "<tr><td class='text-primary'>".$res[0]."</td><td>".$res[1]."</td>".
                            "<td>".getClientInfo($res[4],"Nom")."(".getClientInfo($res[4], "Adresse")." - ".getClientInfo($res[4], "Ville").")</td>".
                            "<td>".getProduitInfo($res[6], "Libelle")." [".$res[7]."]</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php if(isset($_GET['liste']) and $_GET['liste'] == "pr"):?>
            <section>
                <table>
                    <tr class="t-head"><td>Produit</td>
                        <td>Prix Unitaire</td>
                        <td>Quantit&eacute;</td></tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Produit");
                    $req->execute(array());
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res['Libelle']."</td><td>".$res['Montant']."</td><td class='td'>".$res['Quantite']."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php include_once '../Donnees/PHP/Lister.php'; if(isset($_GET['liste']) and $_GET['liste'] == "cm"):?>
            <section>
                <table>
                    <tr class="t-head">
                        <td>Reference</td>
                        <td>Produit</td>
                        <td>Quantit&eacute;</td>
                        <td>Client</td>
                        <td>Date</td>
                    </tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Commande, Concerner WHERE Commande.Code_Cl = ? AND Commande.Ref_Comm = Concerner.Ref_Comm");
                    $req->execute(array($_SESSION['ID']));
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res[0]."</td><td>".getProduitInfo($res[4], "Libelle")."</td><td class='td'>".$res[5]."</td>".
                            "<td>".getClientInfo($res[2], "Nom")."</td><td>".$res[1]."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
        <?php include_once '../Donnees/PHP/Lister.php'; if(isset($_GET['liste']) and $_GET['liste'] == "fa"):?>
            <section>
                <table>
                    <tr class="t-head">
                        <td>Numero Facture</td>
                        <td>Produit</td>
                        <td>Quantit&eacute;</td>
                        <td>Client</td>
                        <td>Montant Pay&eacute;</td>
                        <td>Date de Reglement</td>
                    </tr>
                    <?php
                    $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
                    $req = $db->prepare( "SELECT * FROM Commande, Concerner, Reglement WHERE Commande.Code_Cl = ? AND Commande.Ref_Comm = Concerner.Ref_Comm AND Commande.Ref_Comm = Reglement.Ref_Comm");
                    $req->execute(array($_SESSION['ID']));
                    while($res = $req->fetch()){
                        echo "<tr><td>".$res[0]."-".$res[2]."</td><td>".getProduitInfo($res[4], "Libelle")."</td><td class='td'>".$res[5]."</td>".
                            "<td>".getClientInfo($res[2], "Nom")."</td><td>".$res[9]."</td><td>".$res[8]."</td></tr>";
                    }
                    ?>
                </table><br><br>
                <center><button type="button" onclick="window
            .print();" class="btn btn-special"><b class="fa fa-print"></b> Imprimer</button></center>
            </section>
        <?php endif; ?>
    </center>
<?php endif; ?>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
    </center>
</footer>
<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
</body>
</html>
