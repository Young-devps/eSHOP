<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:24 AM
 */
session_start();
?>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=0.5, shrink-to-fit=no;">
    <title>eShop: Mon Compte</title>
    <link rel="shortcut icon" type="image/png" href="../../Fichier/favicone.png">
    <link rel="stylesheet" href="../Presentation/Style/eFont.css">
    <link rel="stylesheet" href="../Presentation/Style/eShop.css">
    <link rel="stylesheet" href="../Presentation/Style/Style.css">
    <link rel="stylesheet" href="../Presentation/Style/Espace.css">
</head>
<body>
<header style="background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <img src="../../Fichier/favicone.png" width="50" height="50">
        <span  style="font-size:25px">
            <b class="logo">E</b>Shop <hr style="background: #fff;"><br>
        </span>
    </center>
    <div class="text-left">
        <a href="Espace.php?ID=<?=$_SESSION['ID'];?>" class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="text-danger fa fa-arrow-left"></b> Retour</a>
        <?php if(isset($_GET['param']) and $_GET['param'] == "c"):?>
            <a href="#" id='add-c' class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="fa fa-user-plus"></b> Ajouter</a>
        <?php endif; ?>
        <?php if(isset($_GET['param']) and $_GET['param'] == "p"):?>
            <a href="#" id='add-p' class="mr-5 text-white" style="position: relative; top: -30px; left: 15px;"><b class="fa fa-plus"></b> Ajouter</a>
        <?php endif; ?>
    </div>
</header>

<?php if(isset($_GET['param']) and $_GET['param'] == "c"):?>
    <center>
        <form id="form" style='display:none' class="text-dark ml-3" action='../Traitement/Source/addProd.php?type=c' method="post" style="min-height: 400px; max-height: 400px">
            <center>
                <b id="form-legend" class="text-dark fa fa-user small" style="background-color: #fff;font-size: 14px; padding: 10px"></b><br>
                <h5>Client <b class="logo">E</b>Shop</h5>
            </center>
            <center>
                <div id="group1">
                    <div class="group">
                        <input type="text" class="input" name="nom" id="nom" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Nom</label>
                    </div>

                    <div class="group">
                        <input type="text" name="adr" id="addr" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Adresse</label>
                    </div>

                    <div class="group">
                        <input type="text" name="vil" id="vil" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Ville</label>
                    </div>

                    <div style="color: #fff; padding: 5px;">
                        <button type="button" class="btn btn-danger btn-canc">Annuler <b class="fa fa-window-close"></b></button>
                        <button type="submit" class="btn btn-success">Ajouter <b class="fa fa-user-plus"></b></button><br><br>
                    </div>
                </div>
            </center>
        </form>
    </center>
    <table id='tab'>
        <tr class="t-head"><td>Code</td><td>Nom du Client</td><td>Adresse</td><td>Ville</td><td>Action</td></tr>
        <?php
            include_once "../Donnees/PHP/Lister.php";
            $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
            $req = $db->prepare( "SELECT * FROM Client");
            $req->execute(array());
            while($res = $req->fetch()){
                if(isAdmin($res['Code_Cl']) == true or isCompte($res['Code_Cl']) == true){
                    echo "<tr><td>".$res['Code_Cl']."</td><td>".$res['Nom']."</td><td>".$res['Adresse']."</td><td>".$res['Ville']."</td>";
                    echo "<td><a class='mr-2' href='../Traitement/Source/editer.php?client=".$res['Code_Cl']."&type=c'><b class='fa fa-user-edit'></b></a>";
                    echo "<a class='ml-2' href='../Traitement/Source/supprime.php?client=".$res['Code_Cl']."&type=c'><b class='text-danger fa fa-user-times'></b></a></td>";
                    echo "</tr>";
                }
            }
        ?>
    </table>
<?php endif; ?>

<?php if(isset($_GET['param']) and $_GET['param'] == "p"):?>
    <center>
        <form id="form" style='display:none' class="text-dark ml-3" action='../Traitement/Source/addProd.php?type=p' method="post" style="min-height: 400px; max-height: 400px">
            <center>
                <b id="form-legend" class="text-dark fa fa-shopping-basket small" style="background-color: #fff;font-size: 14px; padding: 10px"></b><br>
                <h5>Produit <b class="logo">E</b>Shop</h5>
            </center>
            <center>
                <div id="group1">
                    <div class="group">
                        <input type="text" class="input" name="nom" id="libelle" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Libelle</label>
                    </div>

                    <div class="group">
                        <input type="number" name="pu" id="addr" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Prix Unitaire</label>
                    </div>

                    <div class="group">
                        <input type="number" name="qte" id="vil" class="input" required>
                        <span class="highlight"></span>
                        <span class="bar"></span>
                        <label class="label">Quantit&eacute;</label>
                    </div>

                    <div style="color: #fff; padding: 5px;">
                        <button type="button" class="btn btn-danger btn-canc">Annuler <b class="fa fa-window-close"></b></button>
                        <button type="submit" class="btn btn-success">Ajouter <b class="fa fa-plus"></b></button><br><br>
                    </div>
                </div>
            </center>
        </form>
    </center>
    <table id='tab'>
        <tr class="t-head"><td>Reference</td><td>Lib&eacute;ll&eacute;</td><td>Prix Unitaire</td><td>Quantit&eacute;</td><td>Action</td></tr>
        <?php
            include_once "../Donnees/PHP/Lister.php";
            $db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
            $req = $db->prepare( "SELECT * FROM Produit");
            $req->execute(array());
            while($res = $req->fetch()){
                    echo "<tr><td>".$res['Ref_Prod']."</td><td>".$res['Libelle']."</td><td>".$res['Montant']."</td><td>".$res['Quantite']."</td>";
                    echo "<td><a class='mr-2' href='../Traitement/Source/editer.php?produit=".$res['Ref_Prod']."&type=p' title='Editer'><b class='fa fa-edit'></b></a>";
                    echo "<a class='ml-2' href='../Traitement/Source/supprime.php?produit=".$res['Ref_Prod']."&type=p' title='Supprimer'><b class='text-danger fa fa-window-close'></b></a></td>";
                    echo "</tr>";
            }
        ?>
    </table>
<?php endif; ?>

<footer style="z-index: 1000; background-color: #242424;color: #fff; padding: 5px 0 5px 0;" class="mt-2">
    <center>
        <span class="text-muted small">&copy; 2018 - 2019 <b class="text-white">eShop Inc</b> , Tous droits reserv&eacute;s</span>
    </center>
</footer>

<script src="../Traitement/Script/jquery-3.3.1.min.js"></script>
<script src="../Traitement/Script/eShop.js"></script>
<script src="../Traitement/Script/eFont.js"></script>
<script>
    $('#add-p').click(function(){
        $('#form').show('slow');
        $('#tab').hide();
    });
    $('#add-c').click(function(){
        $('#form').show('slow');
        $('#tab').hide();
    });
    $('.btn-canc').click(function(){
        $('#tab').show('slow');
        $('#form').hide('slow');
    });
</script>
</body>
</html>
