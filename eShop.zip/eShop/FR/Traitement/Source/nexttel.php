<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/11/2019
 * Time: 4:06 AM
 */
$nex = $_POST['next'];
if(strlen($nex) == 9 and $nex[0].$nex[1] == "66"){
    echo "<b class='text-success'>OK</b>";
}
else{
    echo "Ce numero NEXTTEL est invalide";
}
?>