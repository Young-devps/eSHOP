<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/7/2019
 * Time: 5:10 PM
 */

include_once '../../Donnees/PHP/Generateur.php';
include_once '../../Donnees/PHP/Nombre.php';

$l = CompteLigneTable('Produit') - 1;
$r = mt_rand(0, $l);
echo "<img src='../Fichier/Data/".gProduit($r, 'ID').".png' class='prod rounded-circle' width='150' height='150'><br>".
     "<span class='text-muted small'>".gProduit($r, 'Nom')."</span>";
?>