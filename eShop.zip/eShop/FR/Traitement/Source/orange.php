<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/11/2019
 * Time: 4:06 AM
 */
$ora = $_POST['ora'];
if(strlen($ora) == 9 and ($ora[0].$ora[1] == "69" or $ora[0].$ora[1] == "65")){
    echo "<b class='text-success'>OK</b>";
}
else{
    echo "Ce numero ORANGE est invalide";
}
?>