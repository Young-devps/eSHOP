<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 6:34 PM
 */

include_once '../../Donnees/PHP/Ajout.php';
include_once '../../Donnees/PHP/CodeGen.php';

if($_GET['type'] == 'p'){
    $code = CodeProduit();
    $nom = $_POST['nom'];
    $pu = $_POST['pu'];
    $qte = abs($_POST['qte']);

    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
    $rq = $bdd->prepare("INSERT INTO Produit(Ref_Prod, Libelle, Montant, Quantite) VALUES(?, ?, ?, ?)");
    $rq->execute(array($code, $nom, $pu, $qte));

    header('location:../../Presentation/Structure.php?param=p');
}

if($_GET['type'] == 'c'){
    $code = CodeClient();
    $nom = $_POST['nom'];
    $adr = $_POST['adr'];
    $vil = $_POST['vil'];

    $bdd = new PDO("mysql:host=localhost; dbname=Gestion", 'root', '');
    $rq = $bdd->prepare("INSERT INTO Client(Code_Cl, Nom, Adresse, Ville) VALUES(?, ?, ?, ?)");
    $rq->execute(array($code, $nom, $adr, $vil));
    header('location:../../Presentation/Structure.php?param=c');
}

?>