<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 3:03 AM
 */
$email = $_POST['mail'];
mail($email, "Inscription Newsletter", "BIENEVNUE SUR NOTRE NEWSLETTER<br>Vous recevrez nos offres et promotions par Email", "De: eShop Inc ".date('Y'));
$db = new PDO('mysql:host=localhost; dbname=Gestion', 'root', '');
$req = $db->prepare( "INSERT INTO Newsletter(email) VALUES(?)");
$req->execute(array($email));
header('location:../../');
?>