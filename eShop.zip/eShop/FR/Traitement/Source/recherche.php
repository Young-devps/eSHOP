<?php
/**
 * Created by PhpStorm.
 * User: BORIX
 * Date: 1/8/2019
 * Time: 4:30 AM
 */
include_once '../../Donnees/PHP/Recherche.php';

if(strlen($_POST['indice'])){
    $rq = rechercheProduit($_POST['indice']);
    if($rq and mysqli_num_rows($rq)){
        echo "<h5>Produits Disponibles</h5><br><br><table class='tab'><tr><td>Avatar</td><td>Nom</td><td>Prix Unitaire</td><td>Quantite</td></tr>";
        while ($res = mysqli_fetch_assoc($rq)){
            echo "<tr><td><img src='../Fichier/Data/".$res['Ref_Prod'].".png' class='rounded-circle' width='50' height='50'>".
                "</td><td>".$res['Libelle']."</td><td>".$res['Montant']."</td><td>".$res['Quantite']."</td><td></td></tr>";
        }
        echo "</table>";
    }
    else{
        echo "<span class='text-danger'>Aucune suggestion de produits</span>";
    }
}
else{
    echo "";
}
?>